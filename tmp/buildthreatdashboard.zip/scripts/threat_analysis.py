"""
Threat Intelligence Data Analysis
Advanced analytics for security operations
"""

import json
from datetime import datetime, timedelta
from collections import defaultdict
import statistics

def load_threats(filename="threat_data.json"):
    """Load threat data from JSON file"""
    try:
        with open(filename, "r") as f:
            return json.load(f)
    except FileNotFoundError:
        print(f"Error: {filename} not found. Run generate_threat_data.py first.")
        return []


def parse_datetime(dt_string):
    """Parse ISO datetime string"""
    if not dt_string:
        return None
    return datetime.fromisoformat(dt_string)


def time_series_analysis(threats):
    """Analyze attack patterns over time"""
    print("\n" + "="*60)
    print("TIME SERIES ANALYSIS")
    print("="*60)
    
    # Group by hour
    hourly = defaultdict(int)
    daily = defaultdict(int)
    
    for t in threats:
        dt = parse_datetime(t["detected_at"])
        if dt:
            hour_key = dt.strftime("%Y-%m-%d %H:00")
            day_key = dt.strftime("%Y-%m-%d")
            hourly[hour_key] += 1
            daily[day_key] += 1
    
    # Calculate statistics
    hourly_values = list(hourly.values())
    daily_values = list(daily.values())
    
    print("\n--- Hourly Attack Statistics ---")
    print(f"  Average attacks/hour: {statistics.mean(hourly_values):.1f}")
    print(f"  Peak hour attacks: {max(hourly_values)}")
    print(f"  Minimum hour attacks: {min(hourly_values)}")
    print(f"  Std deviation: {statistics.stdev(hourly_values):.1f}")
    
    print("\n--- Daily Attack Statistics ---")
    print(f"  Average attacks/day: {statistics.mean(daily_values):.1f}")
    print(f"  Peak day attacks: {max(daily_values)}")
    print(f"  Days analyzed: {len(daily_values)}")
    
    # Find peak hours
    sorted_hours = sorted(hourly.items(), key=lambda x: x[1], reverse=True)[:5]
    print("\n--- Top 5 Peak Attack Hours ---")
    for hour, count in sorted_hours:
        print(f"  {hour}: {count} attacks")
    
    return {"hourly": dict(hourly), "daily": dict(daily)}


def geographic_analysis(threats):
    """Analyze geographic attack patterns"""
    print("\n" + "="*60)
    print("GEOGRAPHIC THREAT ANALYSIS")
    print("="*60)
    
    # Source analysis
    source_stats = defaultdict(lambda: {"total": 0, "critical": 0, "high": 0, "blocked": 0})
    
    for t in threats:
        country = t["source_country"]
        source_stats[country]["total"] += 1
        if t["severity"] == "critical":
            source_stats[country]["critical"] += 1
        if t["severity"] == "high":
            source_stats[country]["high"] += 1
        if t["blocked"]:
            source_stats[country]["blocked"] += 1
    
    print("\n--- Source Country Risk Assessment ---")
    print(f"{'Country':<20} {'Total':<8} {'Critical':<10} {'High':<8} {'Block Rate':<10}")
    print("-" * 56)
    
    sorted_sources = sorted(source_stats.items(), key=lambda x: x[1]["total"], reverse=True)[:10]
    for country, stats in sorted_sources:
        block_rate = stats["blocked"] / stats["total"] * 100 if stats["total"] > 0 else 0
        print(f"{country:<20} {stats['total']:<8} {stats['critical']:<10} {stats['high']:<8} {block_rate:.1f}%")
    
    # Attack flows (source -> target)
    print("\n--- Top Attack Corridors ---")
    flows = defaultdict(int)
    for t in threats:
        flow = f"{t['source_country']} -> {t['target_country']}"
        flows[flow] += 1
    
    sorted_flows = sorted(flows.items(), key=lambda x: x[1], reverse=True)[:10]
    for flow, count in sorted_flows:
        print(f"  {flow}: {count} attacks")
    
    return {"sources": dict(source_stats), "flows": dict(flows)}


def attack_vector_analysis(threats):
    """Analyze attack types and vectors"""
    print("\n" + "="*60)
    print("ATTACK VECTOR ANALYSIS")
    print("="*60)
    
    # Attack type effectiveness
    type_stats = defaultdict(lambda: {"total": 0, "blocked": 0, "critical": 0})
    
    for t in threats:
        attack_type = t["threat_type"]
        type_stats[attack_type]["total"] += 1
        if t["blocked"]:
            type_stats[attack_type]["blocked"] += 1
        if t["severity"] == "critical":
            type_stats[attack_type]["critical"] += 1
    
    print("\n--- Attack Type Effectiveness ---")
    print(f"{'Attack Type':<20} {'Total':<8} {'Block Rate':<12} {'Critical %':<10}")
    print("-" * 50)
    
    sorted_types = sorted(type_stats.items(), key=lambda x: x[1]["total"], reverse=True)
    for attack_type, stats in sorted_types:
        block_rate = stats["blocked"] / stats["total"] * 100
        critical_rate = stats["critical"] / stats["total"] * 100
        print(f"{attack_type:<20} {stats['total']:<8} {block_rate:.1f}%{'':<6} {critical_rate:.1f}%")
    
    # Calculate threat score (lower block rate = higher threat)
    print("\n--- Threat Score Ranking ---")
    threat_scores = []
    for attack_type, stats in type_stats.items():
        block_rate = stats["blocked"] / stats["total"]
        critical_rate = stats["critical"] / stats["total"]
        # Threat score: weighted combination of success rate and critical rate
        score = (1 - block_rate) * 60 + critical_rate * 40
        threat_scores.append((attack_type, score, stats["total"]))
    
    threat_scores.sort(key=lambda x: x[1], reverse=True)
    for attack_type, score, volume in threat_scores:
        risk_level = "CRITICAL" if score > 40 else "HIGH" if score > 25 else "MEDIUM" if score > 15 else "LOW"
        print(f"  {attack_type}: Score {score:.1f} [{risk_level}] (n={volume})")
    
    return dict(type_stats)


def resolution_time_analysis(threats):
    """Analyze incident resolution times"""
    print("\n" + "="*60)
    print("INCIDENT RESOLUTION ANALYSIS")
    print("="*60)
    
    resolution_times = defaultdict(list)
    
    for t in threats:
        if t["resolved_at"] and t["detected_at"]:
            detected = parse_datetime(t["detected_at"])
            resolved = parse_datetime(t["resolved_at"])
            if detected and resolved:
                duration_mins = (resolved - detected).total_seconds() / 60
                resolution_times[t["severity"]].append(duration_mins)
                resolution_times["all"].append(duration_mins)
    
    print("\n--- Mean Time to Resolution (MTTR) by Severity ---")
    for severity in ["critical", "high", "medium", "low"]:
        times = resolution_times.get(severity, [])
        if times:
            avg = statistics.mean(times)
            median = statistics.median(times)
            print(f"  {severity.upper()}: Avg {avg:.1f} min, Median {median:.1f} min (n={len(times)})")
    
    all_times = resolution_times.get("all", [])
    if all_times:
        print(f"\n  OVERALL: Avg {statistics.mean(all_times):.1f} min, Median {statistics.median(all_times):.1f} min")
        print(f"  95th percentile: {sorted(all_times)[int(len(all_times)*0.95)]:.1f} min")
    
    return dict(resolution_times)


def generate_risk_report(threats):
    """Generate executive risk summary"""
    print("\n" + "="*60)
    print("EXECUTIVE RISK SUMMARY")
    print("="*60)
    
    total = len(threats)
    blocked = sum(1 for t in threats if t["blocked"])
    critical = sum(1 for t in threats if t["severity"] == "critical")
    high = sum(1 for t in threats if t["severity"] == "high")
    
    # Calculate risk metrics
    block_rate = blocked / total * 100
    critical_rate = critical / total * 100
    high_severity_rate = (critical + high) / total * 100
    
    # Overall risk score (0-100)
    risk_score = min(100, max(0, 
        (100 - block_rate) * 0.4 +  # Weight for unblocked attacks
        critical_rate * 3 +          # Weight for critical attacks
        high_severity_rate * 1.5     # Weight for high severity
    ))
    
    risk_level = "CRITICAL" if risk_score > 60 else "HIGH" if risk_score > 40 else "MODERATE" if risk_score > 20 else "LOW"
    
    print(f"\n  OVERALL RISK SCORE: {risk_score:.1f}/100 [{risk_level}]")
    print(f"\n  Key Metrics:")
    print(f"    - Total threats analyzed: {total}")
    print(f"    - Block rate: {block_rate:.1f}%")
    print(f"    - Critical incidents: {critical} ({critical_rate:.1f}%)")
    print(f"    - High severity incidents: {high} ({high/total*100:.1f}%)")
    
    # Top recommendations
    print(f"\n  Recommendations:")
    if block_rate < 80:
        print("    [!] Block rate below 80% - Review and enhance blocking rules")
    if critical_rate > 5:
        print("    [!] High critical incident rate - Immediate security review needed")
    
    # Find most dangerous source
    source_counts = defaultdict(int)
    for t in threats:
        if t["severity"] in ["critical", "high"]:
            source_counts[t["source_country"]] += 1
    
    if source_counts:
        top_threat = max(source_counts.items(), key=lambda x: x[1])
        print(f"    [!] Top threat source: {top_threat[0]} ({top_threat[1]} high/critical attacks)")
    
    return {
        "risk_score": risk_score,
        "risk_level": risk_level,
        "block_rate": block_rate,
        "critical_rate": critical_rate
    }


if __name__ == "__main__":
    # Load data
    threats = load_threats()
    
    if not threats:
        print("No data to analyze. Please run generate_threat_data.py first.")
        exit(1)
    
    print(f"\nLoaded {len(threats)} threat records for analysis")
    
    # Run all analyses
    time_series_analysis(threats)
    geographic_analysis(threats)
    attack_vector_analysis(threats)
    resolution_time_analysis(threats)
    risk_report = generate_risk_report(threats)
    
    # Save full report
    report = {
        "generated_at": datetime.now().isoformat(),
        "threats_analyzed": len(threats),
        "risk_assessment": risk_report
    }
    
    with open("analysis_report.json", "w") as f:
        json.dump(report, f, indent=2)
    
    print("\n" + "="*60)
    print("Analysis complete. Report saved to analysis_report.json")
    print("="*60)
