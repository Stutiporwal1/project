-- Threat Intelligence Database Schema
-- Run this script to create the necessary tables for threat data

-- Main threats table
CREATE TABLE IF NOT EXISTS threats (
    id SERIAL PRIMARY KEY,
    threat_id VARCHAR(50) UNIQUE NOT NULL,
    threat_type VARCHAR(100) NOT NULL,
    severity VARCHAR(20) CHECK (severity IN ('critical', 'high', 'medium', 'low')),
    source_ip VARCHAR(45),
    source_country VARCHAR(100),
    source_city VARCHAR(100),
    target_ip VARCHAR(45),
    target_country VARCHAR(100),
    target_city VARCHAR(100),
    attack_vector VARCHAR(200),
    payload_hash VARCHAR(64),
    blocked BOOLEAN DEFAULT FALSE,
    detected_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    resolved_at TIMESTAMP,
    notes TEXT
);

-- Attack patterns table for ML analysis
CREATE TABLE IF NOT EXISTS attack_patterns (
    id SERIAL PRIMARY KEY,
    pattern_name VARCHAR(200) NOT NULL,
    signature VARCHAR(500),
    frequency INTEGER DEFAULT 0,
    first_seen TIMESTAMP,
    last_seen TIMESTAMP,
    risk_score DECIMAL(5,2)
);

-- Geolocation cache for faster lookups
CREATE TABLE IF NOT EXISTS geo_locations (
    id SERIAL PRIMARY KEY,
    ip_address VARCHAR(45) UNIQUE NOT NULL,
    country VARCHAR(100),
    city VARCHAR(100),
    latitude DECIMAL(10,8),
    longitude DECIMAL(11,8),
    isp VARCHAR(200),
    is_vpn BOOLEAN DEFAULT FALSE,
    is_tor BOOLEAN DEFAULT FALSE,
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Blocked IPs table
CREATE TABLE IF NOT EXISTS blocked_ips (
    id SERIAL PRIMARY KEY,
    ip_address VARCHAR(45) UNIQUE NOT NULL,
    reason VARCHAR(500),
    blocked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP,
    block_count INTEGER DEFAULT 1
);

-- Threat intelligence feeds
CREATE TABLE IF NOT EXISTS threat_feeds (
    id SERIAL PRIMARY KEY,
    feed_name VARCHAR(200) NOT NULL,
    feed_url VARCHAR(500),
    feed_type VARCHAR(50),
    last_sync TIMESTAMP,
    entries_count INTEGER DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE
);

-- Create indexes for better query performance
CREATE INDEX idx_threats_severity ON threats(severity);
CREATE INDEX idx_threats_detected_at ON threats(detected_at);
CREATE INDEX idx_threats_source_country ON threats(source_country);
CREATE INDEX idx_threats_threat_type ON threats(threat_type);
CREATE INDEX idx_geo_locations_ip ON geo_locations(ip_address);
CREATE INDEX idx_blocked_ips_ip ON blocked_ips(ip_address);
