"""
AEGIS Threat Intelligence Platform - Documentation Generator
Generates a comprehensive PDF document with project features and hierarchy
"""

from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.colors import HexColor
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from datetime import datetime

# Create PDF document
doc = SimpleDocTemplate(
    "AEGIS_Platform_Documentation.pdf",
    pagesize=A4,
    rightMargin=0.75*inch,
    leftMargin=0.75*inch,
    topMargin=0.75*inch,
    bottomMargin=0.75*inch
)

# Define colors
PRIMARY_COLOR = HexColor("#0ea5e9")
DARK_COLOR = HexColor("#0f172a")
ACCENT_COLOR = HexColor("#f43f5e")
TEXT_COLOR = HexColor("#334155")

# Define styles
styles = getSampleStyleSheet()

title_style = ParagraphStyle(
    'CustomTitle',
    parent=styles['Title'],
    fontSize=28,
    textColor=PRIMARY_COLOR,
    spaceAfter=20,
    alignment=TA_CENTER,
    fontName='Helvetica-Bold'
)

subtitle_style = ParagraphStyle(
    'Subtitle',
    parent=styles['Normal'],
    fontSize=14,
    textColor=TEXT_COLOR,
    spaceAfter=30,
    alignment=TA_CENTER,
    fontName='Helvetica'
)

heading1_style = ParagraphStyle(
    'Heading1',
    parent=styles['Heading1'],
    fontSize=18,
    textColor=DARK_COLOR,
    spaceBefore=20,
    spaceAfter=12,
    fontName='Helvetica-Bold'
)

heading2_style = ParagraphStyle(
    'Heading2',
    parent=styles['Heading2'],
    fontSize=14,
    textColor=PRIMARY_COLOR,
    spaceBefore=15,
    spaceAfter=8,
    fontName='Helvetica-Bold'
)

heading3_style = ParagraphStyle(
    'Heading3',
    parent=styles['Heading3'],
    fontSize=12,
    textColor=TEXT_COLOR,
    spaceBefore=10,
    spaceAfter=6,
    fontName='Helvetica-Bold'
)

body_style = ParagraphStyle(
    'Body',
    parent=styles['Normal'],
    fontSize=10,
    textColor=TEXT_COLOR,
    spaceAfter=6,
    fontName='Helvetica',
    leading=14
)

bullet_style = ParagraphStyle(
    'Bullet',
    parent=styles['Normal'],
    fontSize=10,
    textColor=TEXT_COLOR,
    spaceAfter=4,
    leftIndent=20,
    fontName='Helvetica',
    leading=12
)

sub_bullet_style = ParagraphStyle(
    'SubBullet',
    parent=styles['Normal'],
    fontSize=9,
    textColor=TEXT_COLOR,
    spaceAfter=3,
    leftIndent=40,
    fontName='Helvetica',
    leading=11
)

# Build content
content = []

# Title Page
content.append(Spacer(1, 2*inch))
content.append(Paragraph("AEGIS", title_style))
content.append(Paragraph("Threat Intelligence Platform", subtitle_style))
content.append(Spacer(1, 0.5*inch))
content.append(Paragraph("Complete Documentation & Feature Hierarchy", body_style))
content.append(Spacer(1, 2*inch))
content.append(Paragraph(f"Generated: {datetime.now().strftime('%B %d, %Y')}", body_style))
content.append(Paragraph("Version: 2.1", body_style))
content.append(Paragraph("Classification: Internal Documentation", body_style))
content.append(PageBreak())

# Table of Contents
content.append(Paragraph("Table of Contents", heading1_style))
content.append(Spacer(1, 0.2*inch))

toc_items = [
    "1. Project Overview",
    "2. Header Bar Components",
    "3. Stats Bar",
    "4. Navigation Tabs",
    "5. Main Dashboard Components",
    "6. Tab-Specific Views",
    "7. Data Analysis Scripts",
    "8. Data Layer",
    "9. Technical Stack",
    "10. Footer"
]

for item in toc_items:
    content.append(Paragraph(item, body_style))

content.append(PageBreak())

# Section 1: Project Overview
content.append(Paragraph("1. Project Overview", heading1_style))
content.append(Paragraph(
    "AEGIS (Advanced Enterprise Guardian Intelligence System) is a comprehensive real-time threat intelligence platform designed for cybersecurity professionals and security operations centers (SOC). The platform provides advanced threat monitoring, AI-powered analysis, and interactive visualizations to help organizations detect, analyze, and respond to cyber threats.",
    body_style
))
content.append(Spacer(1, 0.1*inch))
content.append(Paragraph("Key Capabilities:", heading3_style))
capabilities = [
    "Real-time threat monitoring and visualization",
    "AI-powered threat analysis and predictions",
    "Interactive global attack map with animated attack paths",
    "Multi-source threat intelligence integration",
    "Incident response workflow management",
    "Network topology and threat propagation analysis",
    "MITRE ATT&CK kill chain mapping",
    "Customizable alerting and notification system",
    "Data export in multiple formats (CSV, JSON, PDF)",
    "Database connectivity for enterprise integration"
]
for cap in capabilities:
    content.append(Paragraph(f"- {cap}", bullet_style))

content.append(PageBreak())

# Section 2: Header Bar
content.append(Paragraph("2. Header Bar Components", heading1_style))

content.append(Paragraph("2.1 Branding", heading2_style))
branding_items = [
    "Hexagon logo with animated glow effect",
    "'AEGIS' title with gradient text styling",
    "'Threat Intelligence Platform' subtitle",
    "'100% Secured' status badge with pulse animation"
]
for item in branding_items:
    content.append(Paragraph(f"- {item}", bullet_style))

content.append(Paragraph("2.2 Action Buttons", heading2_style))

content.append(Paragraph("Connect DB - Database Connection Dialog", heading3_style))
connect_db = [
    "Database type selection (PostgreSQL, MySQL, MongoDB)",
    "Connection form with host, port, username, password, database name",
    "Test connection functionality with success/error feedback",
    "Secure credential handling"
]
for item in connect_db:
    content.append(Paragraph(f"  - {item}", sub_bullet_style))

content.append(Paragraph("Export - Data Export Dialog", heading3_style))
export_items = [
    "Format selection: CSV, JSON, PDF",
    "Data type selection: Threat Events, Blocked Attacks, Analytics, AI Predictions",
    "Export progress indicator with visual feedback"
]
for item in export_items:
    content.append(Paragraph(f"  - {item}", sub_bullet_style))

content.append(Paragraph("Chat - AI Security Assistant Panel", heading3_style))
chat_items = [
    "Conversational AI interface for security queries",
    "Quick action buttons: Explain Attack, Show Trends, Check Status, Get Recommendations",
    "Message history with timestamps",
    "Context-aware responses"
]
for item in chat_items:
    content.append(Paragraph(f"  - {item}", sub_bullet_style))

content.append(Paragraph("History - Historical Threat Analysis Modal", heading3_style))
history_items = [
    "Timeline view of past security incidents",
    "Trend analysis and pattern recognition",
    "Historical data comparison"
]
for item in history_items:
    content.append(Paragraph(f"  - {item}", sub_bullet_style))

content.append(Paragraph("2.3 Utility Controls", heading2_style))

content.append(Paragraph("Bell - Notification Toggle", heading3_style))
bell_items = [
    "Enable/disable real-time threat alerts",
    "Visual indicator for alert state"
]
for item in bell_items:
    content.append(Paragraph(f"  - {item}", sub_bullet_style))

content.append(Paragraph("Settings - Configuration Panel", heading3_style))
settings_items = [
    "Theme selection: Light/Dark/System",
    "Refresh interval: 2 seconds to 60 seconds",
    "Notification preferences by severity level (Critical, High, Medium, Low)",
    "Dashboard layout options: Default/Compact/Expanded",
    "Alert thresholds configuration",
    "Sound and email notification toggles"
]
for item in settings_items:
    content.append(Paragraph(f"  - {item}", sub_bullet_style))

content.append(PageBreak())

# Section 3: Stats Bar
content.append(Paragraph("3. Stats Bar", heading1_style))
content.append(Paragraph(
    "The stats bar provides at-a-glance metrics for the current security posture:",
    body_style
))
stats_items = [
    "Active Threats - Current number of active threat events",
    "Blocked Attacks - Count of successfully blocked attack attempts",
    "Critical Threats - Number of critical severity incidents",
    "Assets Monitoring - Total assets under active monitoring"
]
for item in stats_items:
    content.append(Paragraph(f"- {item}", bullet_style))

# Section 4: Navigation Tabs
content.append(Paragraph("4. Navigation Tabs", heading1_style))
content.append(Paragraph(
    "The platform features a tabbed navigation system for accessing different functional areas:",
    body_style
))
tabs = [
    ("Analytics", "Default dashboard view with comprehensive threat analytics"),
    ("Threat Feed", "Real-time stream of threat events and alerts"),
    ("Incident Response", "Workflow tools for incident handling and response"),
    ("Threat Intel", "Threat intelligence data and global attack visualization"),
    ("IP Verify", "IP address reputation and verification lookup"),
    ("Network", "Network topology and connection analysis"),
    ("AI Predictions", "Machine learning-based threat predictions"),
    ("Static Upload", "File upload for malware analysis"),
    ("API Data", "External API integration and data feeds")
]
for tab, desc in tabs:
    content.append(Paragraph(f"- <b>{tab}</b> - {desc}", bullet_style))

content.append(PageBreak())

# Section 5: Main Dashboard Components
content.append(Paragraph("5. Main Dashboard Components", heading1_style))

content.append(Paragraph("5.1 World Map (Attack Visualization)", heading2_style))
worldmap_items = [
    "SVG-based continent outlines on dark oceanic background",
    "Real-time attack path animations using bezier curves",
    "Color-coded severity indicators (Red=Critical, Orange=High, Yellow=Medium)",
    "Pulsing source and target location indicators",
    "Interactive tooltips displaying attack details (IP, location, type, severity, timestamp)",
    "Overlay counters for active and blocked attacks",
    "City name labels for attack origins and destinations"
]
for item in worldmap_items:
    content.append(Paragraph(f"- {item}", bullet_style))

content.append(Paragraph("5.2 ML Model Selector", heading2_style))
ml_items = [
    "Machine learning model selection dropdown",
    "Model performance metrics display",
    "Training status indicators",
    "Model accuracy and confidence scores"
]
for item in ml_items:
    content.append(Paragraph(f"- {item}", bullet_style))

content.append(Paragraph("5.3 Threat Pulse", heading2_style))
pulse_items = [
    "Real-time threat activity visualization",
    "Animated pulse indicators showing threat frequency",
    "Threat level gauges with dynamic updates"
]
for item in pulse_items:
    content.append(Paragraph(f"- {item}", bullet_style))

content.append(Paragraph("5.4 Risk Matrix", heading2_style))
risk_items = [
    "Severity vs Likelihood assessment grid",
    "Color-coded risk zones (Low, Medium, High, Critical)",
    "Interactive risk assessment interface",
    "Risk score calculations"
]
for item in risk_items:
    content.append(Paragraph(f"- {item}", bullet_style))

content.append(Paragraph("5.5 Network Graph", heading2_style))
network_items = [
    "Node-based network topology visualization",
    "Connection relationship mapping",
    "Threat propagation path analysis",
    "Interactive node inspection"
]
for item in network_items:
    content.append(Paragraph(f"- {item}", bullet_style))

content.append(Paragraph("5.6 Kill Chain", heading2_style))
killchain_items = [
    "MITRE ATT&CK framework stage visualization",
    "Attack progression tracking",
    "Stage-by-stage breakdown (Reconnaissance, Weaponization, Delivery, Exploitation, Installation, C2, Actions)"
]
for item in killchain_items:
    content.append(Paragraph(f"- {item}", bullet_style))

content.append(Paragraph("5.7 Command Center", heading2_style))
command_items = [
    "Quick action controls for threat response",
    "Block/Allow/Investigate action buttons",
    "Status indicators for response actions",
    "Escalation workflows"
]
for item in command_items:
    content.append(Paragraph(f"- {item}", bullet_style))

content.append(Paragraph("5.8 Prediction Card", heading2_style))
prediction_items = [
    "AI-generated threat predictions",
    "Confidence scores for predictions",
    "Recommended defensive actions",
    "Predicted attack vectors and targets"
]
for item in prediction_items:
    content.append(Paragraph(f"- {item}", bullet_style))

content.append(Paragraph("5.9 Event Feed", heading2_style))
event_items = [
    "Real-time threat event list with live updates",
    "Severity badges (Critical/High/Medium/Low) with color coding",
    "Source IP addresses and geographic locations",
    "Attack type classification",
    "Timestamps with relative time display",
    "Expandable view mode for detailed analysis"
]
for item in event_items:
    content.append(Paragraph(f"- {item}", bullet_style))

content.append(PageBreak())

# Section 6: Tab-Specific Views
content.append(Paragraph("6. Tab-Specific Views", heading1_style))
content.append(Paragraph(
    "Each navigation tab presents a customized view optimized for specific workflows:",
    body_style
))

tab_views = [
    ("Threat Feed", "Expanded event feed with full-width display, filtering, and sorting capabilities"),
    ("Incident Response", "Kill Chain visualization + Command Center + Critical events panel for incident handling"),
    ("Threat Intel", "World Map + Risk Matrix for global threat intelligence analysis"),
    ("IP Verify", "IP address lookup tool with reputation scoring and threat indicators"),
    ("Network", "Network Graph + Threat Pulse for network topology and activity analysis"),
    ("AI Predictions", "ML Model Selector + Prediction Card for AI-driven threat forecasting"),
    ("Static Upload", "Drag-and-drop file upload interface for malware/file analysis"),
    ("API Data", "External API configuration and data integration management")
]
for tab, desc in tab_views:
    content.append(Paragraph(f"<b>{tab}</b>", heading3_style))
    content.append(Paragraph(desc, bullet_style))

content.append(PageBreak())

# Section 7: Data Analysis Scripts
content.append(Paragraph("7. Data Analysis Scripts", heading1_style))

content.append(Paragraph("7.1 SQL Scripts", heading2_style))

content.append(Paragraph("001-threat-schema.sql", heading3_style))
schema_items = [
    "threats - Main threat event storage table",
    "attack_patterns - Known attack pattern definitions",
    "geo_locations - Geographic location reference data",
    "blocked_ips - Blacklisted IP addresses",
    "threat_feeds - External threat intelligence feeds",
    "Indexes for optimized query performance",
    "Foreign key relationships for data integrity"
]
for item in schema_items:
    content.append(Paragraph(f"  - {item}", sub_bullet_style))

content.append(Paragraph("002-analytics-queries.sql", heading3_style))
analytics_items = [
    "Top attackers by volume and severity",
    "Attack trends over time periods",
    "Botnet detection queries",
    "Geographic distribution analysis",
    "Attack type frequency analysis",
    "Response time metrics"
]
for item in analytics_items:
    content.append(Paragraph(f"  - {item}", sub_bullet_style))

content.append(Paragraph("7.2 Python Scripts", heading2_style))

content.append(Paragraph("generate_threat_data.py", heading3_style))
gen_items = [
    "Generates 1000 realistic synthetic threat records",
    "Weighted distributions for attack types",
    "Geographic source distribution based on real-world patterns",
    "Severity level distribution matching industry statistics"
]
for item in gen_items:
    content.append(Paragraph(f"  - {item}", sub_bullet_style))

content.append(Paragraph("threat_analysis.py", heading3_style))
analysis_items = [
    "Time series analysis of threat patterns",
    "Geographic pattern identification",
    "Attack vector effectiveness scoring",
    "Resolution time calculations",
    "Executive risk scoring algorithms"
]
for item in analysis_items:
    content.append(Paragraph(f"  - {item}", sub_bullet_style))

content.append(Paragraph("visualize_threats.py", heading3_style))
viz_items = [
    "Matplotlib-based visualizations",
    "Pie charts for attack type distribution",
    "Bar charts for geographic analysis",
    "Trend lines for temporal patterns",
    "Full dashboard summary generation"
]
for item in viz_items:
    content.append(Paragraph(f"  - {item}", sub_bullet_style))

content.append(PageBreak())

# Section 8: Data Layer
content.append(Paragraph("8. Data Layer", heading1_style))
content.append(Paragraph(
    "The platform's data layer provides type-safe data structures and utility functions:",
    body_style
))

content.append(Paragraph("lib/threat-data.ts", heading3_style))
data_items = [
    "TypeScript type definitions for threats, attacks, and events",
    "Mock data generation functions for development",
    "Attack type enumerations",
    "Severity level definitions",
    "Geographic coordinate mappings"
]
for item in data_items:
    content.append(Paragraph(f"- {item}", bullet_style))

content.append(Paragraph("lib/utils.ts", heading3_style))
utils_items = [
    "cn() - Tailwind CSS class name merger utility",
    "Date formatting helpers",
    "Data transformation functions"
]
for item in utils_items:
    content.append(Paragraph(f"- {item}", bullet_style))

# Section 9: Technical Stack
content.append(Paragraph("9. Technical Stack", heading1_style))

tech_table_data = [
    ["Category", "Technology"],
    ["Framework", "Next.js 16 with App Router"],
    ["Language", "TypeScript"],
    ["UI Library", "React 19"],
    ["Styling", "Tailwind CSS v4"],
    ["Components", "shadcn/ui (Radix UI primitives)"],
    ["Charts", "Recharts"],
    ["Icons", "Lucide React"],
    ["Notifications", "Sonner (Toast)"],
    ["Data Analysis", "Python (pandas, numpy, matplotlib)"],
    ["Database", "SQL (PostgreSQL/MySQL/MongoDB ready)"]
]

tech_table = Table(tech_table_data, colWidths=[2*inch, 4*inch])
tech_table.setStyle(TableStyle([
    ('BACKGROUND', (0, 0), (-1, 0), PRIMARY_COLOR),
    ('TEXTCOLOR', (0, 0), (-1, 0), HexColor("#ffffff")),
    ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
    ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
    ('FONTSIZE', (0, 0), (-1, 0), 11),
    ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
    ('TOPPADDING', (0, 0), (-1, 0), 12),
    ('BACKGROUND', (0, 1), (-1, -1), HexColor("#f8fafc")),
    ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
    ('FONTSIZE', (0, 1), (-1, -1), 10),
    ('BOTTOMPADDING', (0, 1), (-1, -1), 8),
    ('TOPPADDING', (0, 1), (-1, -1), 8),
    ('GRID', (0, 0), (-1, -1), 0.5, HexColor("#e2e8f0")),
]))
content.append(tech_table)

# Section 10: Footer
content.append(Spacer(1, 0.3*inch))
content.append(Paragraph("10. Footer", heading1_style))
footer_items = [
    "Version display: AEGIS v2.1",
    "Last sync timestamp with real-time updates",
    "System status indicator"
]
for item in footer_items:
    content.append(Paragraph(f"- {item}", bullet_style))

# Final page
content.append(PageBreak())
content.append(Spacer(1, 2*inch))
content.append(Paragraph("End of Documentation", title_style))
content.append(Spacer(1, 0.5*inch))
content.append(Paragraph(
    "For questions or support, contact the AEGIS development team.",
    body_style
))
content.append(Paragraph(
    f"Document generated on {datetime.now().strftime('%B %d, %Y at %H:%M:%S')}",
    body_style
))

# Build PDF
doc.build(content)
print("PDF documentation generated successfully: AEGIS_Platform_Documentation.pdf")
