-- Threat Intelligence Analytics Queries
-- Common queries used by security analysts

-- 1. Top 10 attacking countries in last 24 hours
SELECT 
    source_country,
    COUNT(*) as attack_count,
    COUNT(CASE WHEN severity = 'critical' THEN 1 END) as critical_count,
    COUNT(CASE WHEN severity = 'high' THEN 1 END) as high_count,
    ROUND(COUNT(CASE WHEN blocked = TRUE THEN 1 END)::DECIMAL / COUNT(*) * 100, 2) as block_rate
FROM threats
WHERE detected_at >= NOW() - INTERVAL '24 hours'
GROUP BY source_country
ORDER BY attack_count DESC
LIMIT 10;

-- 2. Attack type distribution with severity breakdown
SELECT 
    threat_type,
    severity,
    COUNT(*) as count,
    ROUND(AVG(EXTRACT(EPOCH FROM (resolved_at - detected_at))/60), 2) as avg_resolution_mins
FROM threats
WHERE detected_at >= NOW() - INTERVAL '7 days'
GROUP BY threat_type, severity
ORDER BY count DESC;

-- 3. Hourly attack trend for the past week
SELECT 
    DATE_TRUNC('hour', detected_at) as hour,
    COUNT(*) as total_attacks,
    COUNT(CASE WHEN blocked = TRUE THEN 1 END) as blocked_attacks,
    COUNT(CASE WHEN severity IN ('critical', 'high') THEN 1 END) as high_severity
FROM threats
WHERE detected_at >= NOW() - INTERVAL '7 days'
GROUP BY DATE_TRUNC('hour', detected_at)
ORDER BY hour;

-- 4. Identify potential botnet activity (same source hitting multiple targets)
SELECT 
    source_ip,
    source_country,
    COUNT(DISTINCT target_ip) as unique_targets,
    COUNT(*) as total_attacks,
    ARRAY_AGG(DISTINCT threat_type) as attack_types
FROM threats
WHERE detected_at >= NOW() - INTERVAL '1 hour'
GROUP BY source_ip, source_country
HAVING COUNT(DISTINCT target_ip) > 5
ORDER BY unique_targets DESC;

-- 5. Attack patterns correlation
SELECT 
    ap.pattern_name,
    ap.risk_score,
    COUNT(t.id) as occurrences,
    MAX(t.detected_at) as last_occurrence
FROM attack_patterns ap
LEFT JOIN threats t ON t.attack_vector LIKE '%' || ap.signature || '%'
WHERE t.detected_at >= NOW() - INTERVAL '24 hours'
GROUP BY ap.id, ap.pattern_name, ap.risk_score
ORDER BY ap.risk_score DESC, occurrences DESC;

-- 6. Geographic attack flow analysis
SELECT 
    source_country,
    target_country,
    COUNT(*) as attack_count,
    STRING_AGG(DISTINCT threat_type, ', ') as attack_types
FROM threats
WHERE detected_at >= NOW() - INTERVAL '24 hours'
GROUP BY source_country, target_country
ORDER BY attack_count DESC
LIMIT 20;

-- 7. VPN/Tor exit node detection
SELECT 
    t.source_ip,
    g.is_vpn,
    g.is_tor,
    g.isp,
    COUNT(*) as attack_count
FROM threats t
JOIN geo_locations g ON t.source_ip = g.ip_address
WHERE (g.is_vpn = TRUE OR g.is_tor = TRUE)
  AND t.detected_at >= NOW() - INTERVAL '24 hours'
GROUP BY t.source_ip, g.is_vpn, g.is_tor, g.isp
ORDER BY attack_count DESC;

-- 8. Repeat offenders analysis
SELECT 
    b.ip_address,
    b.block_count,
    b.reason,
    COUNT(t.id) as attacks_after_block
FROM blocked_ips b
LEFT JOIN threats t ON b.ip_address = t.source_ip 
  AND t.detected_at > b.blocked_at
GROUP BY b.ip_address, b.block_count, b.reason
HAVING COUNT(t.id) > 0
ORDER BY attacks_after_block DESC;
