"""
Threat Data Generator
Generates realistic threat intelligence data for analysis
"""

import json
import random
from datetime import datetime, timedelta
import hashlib

# Attack types with realistic weights
ATTACK_TYPES = [
    ("DDoS Attack", 0.25),
    ("SQL Injection", 0.15),
    ("Brute Force", 0.20),
    ("Malware", 0.12),
    ("Phishing", 0.10),
    ("XSS Attack", 0.08),
    ("Zero-Day Exploit", 0.02),
    ("Ransomware", 0.05),
    ("Man-in-the-Middle", 0.03),
]

# Source countries with attack frequency weights
SOURCE_COUNTRIES = [
    ("Russia", 0.18, ["Moscow", "St. Petersburg", "Novosibirsk"]),
    ("China", 0.22, ["Beijing", "Shanghai", "Shenzhen", "Guangzhou"]),
    ("United States", 0.12, ["New York", "Los Angeles", "Chicago", "Houston"]),
    ("North Korea", 0.08, ["Pyongyang"]),
    ("Iran", 0.07, ["Tehran", "Isfahan"]),
    ("Brazil", 0.06, ["São Paulo", "Rio de Janeiro"]),
    ("India", 0.05, ["Mumbai", "Delhi", "Bangalore"]),
    ("Nigeria", 0.04, ["Lagos", "Abuja"]),
    ("Vietnam", 0.04, ["Hanoi", "Ho Chi Minh City"]),
    ("Ukraine", 0.03, ["Kyiv", "Kharkiv"]),
    ("Romania", 0.03, ["Bucharest"]),
    ("Indonesia", 0.03, ["Jakarta"]),
    ("Turkey", 0.02, ["Istanbul", "Ankara"]),
    ("Germany", 0.02, ["Berlin", "Frankfurt"]),
    ("Netherlands", 0.01, ["Amsterdam"]),
]

TARGET_COUNTRIES = [
    ("United States", 0.35, ["New York", "San Francisco", "Chicago", "Dallas"]),
    ("United Kingdom", 0.15, ["London", "Manchester"]),
    ("Germany", 0.12, ["Frankfurt", "Berlin", "Munich"]),
    ("France", 0.08, ["Paris", "Lyon"]),
    ("Japan", 0.08, ["Tokyo", "Osaka"]),
    ("Australia", 0.07, ["Sydney", "Melbourne"]),
    ("Canada", 0.06, ["Toronto", "Vancouver"]),
    ("Singapore", 0.05, ["Singapore"]),
    ("South Korea", 0.04, ["Seoul"]),
]

SEVERITY_WEIGHTS = [("critical", 0.08), ("high", 0.22), ("medium", 0.45), ("low", 0.25)]


def weighted_choice(choices):
    """Select item based on weights"""
    items, weights = zip(*[(c[0], c[1]) for c in choices])
    return random.choices(items, weights=weights, k=1)[0]


def get_country_data(countries, country_name):
    """Get full country data tuple"""
    for c in countries:
        if c[0] == country_name:
            return c
    return countries[0]


def generate_ip():
    """Generate random IP address"""
    return f"{random.randint(1,255)}.{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(1,254)}"


def generate_threat(base_time):
    """Generate a single threat event"""
    # Select attack type
    attack_type = weighted_choice(ATTACK_TYPES)
    
    # Select source
    source_country_name = weighted_choice(SOURCE_COUNTRIES)
    source_data = get_country_data(SOURCE_COUNTRIES, source_country_name)
    source_city = random.choice(source_data[2])
    
    # Select target
    target_country_name = weighted_choice(TARGET_COUNTRIES)
    target_data = get_country_data(TARGET_COUNTRIES, target_country_name)
    target_city = random.choice(target_data[2])
    
    # Select severity
    severity = weighted_choice(SEVERITY_WEIGHTS)
    
    # Generate timestamps
    detected_at = base_time - timedelta(
        hours=random.randint(0, 168),
        minutes=random.randint(0, 59),
        seconds=random.randint(0, 59)
    )
    
    # Determine if blocked (higher severity = more likely blocked)
    block_probability = {"critical": 0.95, "high": 0.85, "medium": 0.70, "low": 0.50}
    blocked = random.random() < block_probability[severity]
    
    # Resolution time (if resolved)
    resolved_at = None
    if blocked or random.random() < 0.7:
        resolution_mins = random.randint(1, 120) if severity == "critical" else random.randint(5, 480)
        resolved_at = detected_at + timedelta(minutes=resolution_mins)
    
    # Generate payload hash
    payload_hash = hashlib.sha256(f"{attack_type}{detected_at}{random.random()}".encode()).hexdigest()
    
    return {
        "threat_id": f"THR-{random.randint(100000, 999999)}",
        "threat_type": attack_type,
        "severity": severity,
        "source_ip": generate_ip(),
        "source_country": source_country_name,
        "source_city": source_city,
        "target_ip": generate_ip(),
        "target_country": target_country_name,
        "target_city": target_city,
        "attack_vector": f"{attack_type} via {'port ' + str(random.choice([22, 80, 443, 3306, 8080, 3389])) if attack_type != 'Phishing' else 'email'}",
        "payload_hash": payload_hash,
        "blocked": blocked,
        "detected_at": detected_at.isoformat(),
        "resolved_at": resolved_at.isoformat() if resolved_at else None,
    }


def generate_dataset(num_threats=1000):
    """Generate full threat dataset"""
    base_time = datetime.now()
    threats = [generate_threat(base_time) for _ in range(num_threats)]
    
    # Sort by detection time
    threats.sort(key=lambda x: x["detected_at"], reverse=True)
    
    return threats


def analyze_dataset(threats):
    """Perform basic analysis on the dataset"""
    print("\n" + "="*60)
    print("THREAT INTELLIGENCE ANALYSIS REPORT")
    print("="*60)
    
    total = len(threats)
    blocked = sum(1 for t in threats if t["blocked"])
    
    print(f"\nTotal Threats: {total}")
    print(f"Blocked: {blocked} ({blocked/total*100:.1f}%)")
    print(f"Unblocked: {total - blocked} ({(total-blocked)/total*100:.1f}%)")
    
    # Severity breakdown
    print("\n--- Severity Distribution ---")
    for severity in ["critical", "high", "medium", "low"]:
        count = sum(1 for t in threats if t["severity"] == severity)
        print(f"  {severity.upper()}: {count} ({count/total*100:.1f}%)")
    
    # Top source countries
    print("\n--- Top 5 Attack Sources ---")
    country_counts = {}
    for t in threats:
        country_counts[t["source_country"]] = country_counts.get(t["source_country"], 0) + 1
    
    sorted_countries = sorted(country_counts.items(), key=lambda x: x[1], reverse=True)[:5]
    for country, count in sorted_countries:
        print(f"  {country}: {count} attacks ({count/total*100:.1f}%)")
    
    # Attack types
    print("\n--- Attack Type Distribution ---")
    type_counts = {}
    for t in threats:
        type_counts[t["threat_type"]] = type_counts.get(t["threat_type"], 0) + 1
    
    sorted_types = sorted(type_counts.items(), key=lambda x: x[1], reverse=True)
    for attack_type, count in sorted_types:
        print(f"  {attack_type}: {count} ({count/total*100:.1f}%)")
    
    # Critical threats summary
    print("\n--- Critical Threats Summary ---")
    critical = [t for t in threats if t["severity"] == "critical"]
    critical_blocked = sum(1 for t in critical if t["blocked"])
    print(f"  Total Critical: {len(critical)}")
    print(f"  Blocked: {critical_blocked} ({critical_blocked/len(critical)*100:.1f}% block rate)")
    
    return {
        "total_threats": total,
        "blocked_count": blocked,
        "block_rate": blocked/total,
        "severity_distribution": {s: sum(1 for t in threats if t["severity"] == s) for s in ["critical", "high", "medium", "low"]},
        "top_sources": dict(sorted_countries),
        "attack_types": dict(sorted_types)
    }


if __name__ == "__main__":
    # Generate dataset
    print("Generating threat intelligence dataset...")
    threats = generate_dataset(1000)
    
    # Save to JSON
    with open("threat_data.json", "w") as f:
        json.dump(threats, f, indent=2)
    print(f"Generated {len(threats)} threat records -> threat_data.json")
    
    # Perform analysis
    summary = analyze_dataset(threats)
    
    # Save summary
    with open("threat_summary.json", "w") as f:
        json.dump(summary, f, indent=2)
    print("\nSummary saved to threat_summary.json")
