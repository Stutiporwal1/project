"""
Threat Data Visualization
Generate charts and visual reports using matplotlib
"""

import json
from datetime import datetime
from collections import defaultdict
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np

def load_threats(filename="threat_data.json"):
    """Load threat data from JSON file"""
    try:
        with open(filename, "r") as f:
            return json.load(f)
    except FileNotFoundError:
        print(f"Error: {filename} not found. Run generate_threat_data.py first.")
        return []


def create_severity_pie_chart(threats):
    """Create pie chart of severity distribution"""
    severity_counts = defaultdict(int)
    for t in threats:
        severity_counts[t["severity"]] += 1
    
    labels = ["Critical", "High", "Medium", "Low"]
    sizes = [severity_counts.get(s.lower(), 0) for s in labels]
    colors = ["#dc2626", "#f97316", "#eab308", "#22c55e"]
    explode = (0.05, 0.02, 0, 0)
    
    fig, ax = plt.subplots(figsize=(8, 6))
    ax.pie(sizes, explode=explode, labels=labels, colors=colors, autopct='%1.1f%%',
           shadow=True, startangle=90)
    ax.set_title("Threat Severity Distribution", fontsize=14, fontweight="bold")
    
    plt.tight_layout()
    plt.savefig("severity_distribution.png", dpi=150, bbox_inches="tight")
    print("Saved: severity_distribution.png")
    plt.close()


def create_source_country_bar(threats):
    """Create bar chart of top attacking countries"""
    country_counts = defaultdict(int)
    for t in threats:
        country_counts[t["source_country"]] += 1
    
    # Get top 10
    sorted_countries = sorted(country_counts.items(), key=lambda x: x[1], reverse=True)[:10]
    countries = [c[0] for c in sorted_countries]
    counts = [c[1] for c in sorted_countries]
    
    fig, ax = plt.subplots(figsize=(12, 6))
    bars = ax.barh(countries[::-1], counts[::-1], color="#3b82f6")
    
    # Add value labels
    for bar, count in zip(bars, counts[::-1]):
        ax.text(bar.get_width() + 5, bar.get_y() + bar.get_height()/2, 
                str(count), va="center", fontsize=10)
    
    ax.set_xlabel("Number of Attacks", fontsize=12)
    ax.set_title("Top 10 Attack Source Countries", fontsize=14, fontweight="bold")
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    
    plt.tight_layout()
    plt.savefig("source_countries.png", dpi=150, bbox_inches="tight")
    print("Saved: source_countries.png")
    plt.close()


def create_attack_type_chart(threats):
    """Create horizontal bar chart of attack types"""
    type_counts = defaultdict(lambda: {"total": 0, "blocked": 0})
    
    for t in threats:
        type_counts[t["threat_type"]]["total"] += 1
        if t["blocked"]:
            type_counts[t["threat_type"]]["blocked"] += 1
    
    sorted_types = sorted(type_counts.items(), key=lambda x: x[1]["total"], reverse=True)
    attack_types = [t[0] for t in sorted_types]
    totals = [t[1]["total"] for t in sorted_types]
    blocked = [t[1]["blocked"] for t in sorted_types]
    unblocked = [t - b for t, b in zip(totals, blocked)]
    
    fig, ax = plt.subplots(figsize=(12, 7))
    
    y = np.arange(len(attack_types))
    height = 0.6
    
    bars1 = ax.barh(y, blocked[::-1], height, label="Blocked", color="#22c55e")
    bars2 = ax.barh(y, unblocked[::-1], height, left=blocked[::-1], label="Unblocked", color="#ef4444")
    
    ax.set_yticks(y)
    ax.set_yticklabels(attack_types[::-1])
    ax.set_xlabel("Number of Attacks", fontsize=12)
    ax.set_title("Attack Types: Blocked vs Unblocked", fontsize=14, fontweight="bold")
    ax.legend(loc="lower right")
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    
    plt.tight_layout()
    plt.savefig("attack_types.png", dpi=150, bbox_inches="tight")
    print("Saved: attack_types.png")
    plt.close()


def create_hourly_trend(threats):
    """Create line chart of hourly attack trends"""
    hourly = defaultdict(lambda: {"total": 0, "critical": 0, "blocked": 0})
    
    for t in threats:
        dt = datetime.fromisoformat(t["detected_at"])
        hour = dt.hour
        hourly[hour]["total"] += 1
        if t["severity"] == "critical":
            hourly[hour]["critical"] += 1
        if t["blocked"]:
            hourly[hour]["blocked"] += 1
    
    hours = list(range(24))
    totals = [hourly[h]["total"] for h in hours]
    criticals = [hourly[h]["critical"] for h in hours]
    
    fig, ax = plt.subplots(figsize=(12, 5))
    
    ax.fill_between(hours, totals, alpha=0.3, color="#3b82f6")
    ax.plot(hours, totals, color="#3b82f6", linewidth=2, label="Total Attacks", marker="o", markersize=4)
    ax.plot(hours, criticals, color="#dc2626", linewidth=2, label="Critical", marker="s", markersize=4)
    
    ax.set_xlabel("Hour of Day (UTC)", fontsize=12)
    ax.set_ylabel("Number of Attacks", fontsize=12)
    ax.set_title("Hourly Attack Distribution", fontsize=14, fontweight="bold")
    ax.set_xticks(hours)
    ax.legend()
    ax.grid(True, alpha=0.3)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    
    plt.tight_layout()
    plt.savefig("hourly_trend.png", dpi=150, bbox_inches="tight")
    print("Saved: hourly_trend.png")
    plt.close()


def create_block_rate_gauge(threats):
    """Create a gauge chart showing overall block rate"""
    blocked = sum(1 for t in threats if t["blocked"])
    total = len(threats)
    block_rate = blocked / total * 100
    
    fig, ax = plt.subplots(figsize=(8, 4), subplot_kw={"projection": "polar"})
    
    # Create gauge
    theta = np.linspace(0, np.pi, 100)
    
    # Background arc
    ax.fill_between(theta, 0.7, 1.0, color="#e5e7eb", alpha=0.5)
    
    # Colored sections
    green_end = int(80 / 100 * 100)
    yellow_end = int(60 / 100 * 100)
    red_end = int(40 / 100 * 100)
    
    ax.fill_between(theta[:green_end], 0.7, 1.0, color="#22c55e", alpha=0.7)
    ax.fill_between(theta[red_end:yellow_end], 0.7, 1.0, color="#eab308", alpha=0.7)
    ax.fill_between(theta[:red_end], 0.7, 1.0, color="#ef4444", alpha=0.7)
    
    # Needle
    needle_angle = np.pi * (1 - block_rate / 100)
    ax.annotate("", xy=(needle_angle, 0.9), xytext=(needle_angle, 0),
                arrowprops=dict(arrowstyle="->", color="#1f2937", lw=3))
    
    # Value text
    ax.text(np.pi/2, 0.3, f"{block_rate:.1f}%", ha="center", va="center", 
            fontsize=24, fontweight="bold", color="#1f2937")
    ax.text(np.pi/2, 0.1, "Block Rate", ha="center", va="center", 
            fontsize=12, color="#6b7280")
    
    ax.set_ylim(0, 1)
    ax.set_theta_zero_location("W")
    ax.set_theta_direction(-1)
    ax.set_thetamin(0)
    ax.set_thetamax(180)
    ax.axis("off")
    
    plt.tight_layout()
    plt.savefig("block_rate_gauge.png", dpi=150, bbox_inches="tight", facecolor="white")
    print("Saved: block_rate_gauge.png")
    plt.close()


def create_dashboard_summary(threats):
    """Create a summary dashboard image"""
    fig = plt.figure(figsize=(14, 10))
    fig.suptitle("Threat Intelligence Dashboard", fontsize=18, fontweight="bold", y=0.98)
    
    # Calculate metrics
    total = len(threats)
    blocked = sum(1 for t in threats if t["blocked"])
    critical = sum(1 for t in threats if t["severity"] == "critical")
    high = sum(1 for t in threats if t["severity"] == "high")
    
    # 1. Key metrics boxes
    ax1 = fig.add_axes([0.05, 0.75, 0.9, 0.18])
    ax1.axis("off")
    
    metrics = [
        ("Total Threats", str(total), "#3b82f6"),
        ("Blocked", str(blocked), "#22c55e"),
        ("Critical", str(critical), "#dc2626"),
        ("High", str(high), "#f97316"),
        ("Block Rate", f"{blocked/total*100:.1f}%", "#8b5cf6")
    ]
    
    for i, (label, value, color) in enumerate(metrics):
        x = 0.1 + i * 0.18
        rect = mpatches.FancyBboxPatch((x, 0.2), 0.15, 0.6, boxstyle="round,pad=0.02",
                                        facecolor=color, alpha=0.15, edgecolor=color, linewidth=2)
        ax1.add_patch(rect)
        ax1.text(x + 0.075, 0.65, value, ha="center", va="center", fontsize=20, fontweight="bold", color=color)
        ax1.text(x + 0.075, 0.35, label, ha="center", va="center", fontsize=10, color="#6b7280")
    
    ax1.set_xlim(0, 1)
    ax1.set_ylim(0, 1)
    
    # 2. Severity pie chart
    ax2 = fig.add_subplot(2, 2, 3)
    severity_counts = defaultdict(int)
    for t in threats:
        severity_counts[t["severity"]] += 1
    
    labels = ["Critical", "High", "Medium", "Low"]
    sizes = [severity_counts.get(s.lower(), 0) for s in labels]
    colors = ["#dc2626", "#f97316", "#eab308", "#22c55e"]
    ax2.pie(sizes, labels=labels, colors=colors, autopct="%1.1f%%", startangle=90)
    ax2.set_title("Severity Distribution", fontweight="bold")
    
    # 3. Top sources bar chart
    ax3 = fig.add_subplot(2, 2, 4)
    country_counts = defaultdict(int)
    for t in threats:
        country_counts[t["source_country"]] += 1
    
    sorted_countries = sorted(country_counts.items(), key=lambda x: x[1], reverse=True)[:5]
    countries = [c[0] for c in sorted_countries]
    counts = [c[1] for c in sorted_countries]
    
    bars = ax3.barh(countries[::-1], counts[::-1], color="#3b82f6")
    ax3.set_title("Top 5 Attack Sources", fontweight="bold")
    ax3.spines["top"].set_visible(False)
    ax3.spines["right"].set_visible(False)
    
    plt.tight_layout(rect=[0, 0, 1, 0.95])
    plt.savefig("dashboard_summary.png", dpi=150, bbox_inches="tight", facecolor="white")
    print("Saved: dashboard_summary.png")
    plt.close()


if __name__ == "__main__":
    # Load data
    threats = load_threats()
    
    if not threats:
        print("No data to visualize. Please run generate_threat_data.py first.")
        exit(1)
    
    print(f"Loaded {len(threats)} threat records for visualization\n")
    
    # Generate all charts
    print("Generating visualizations...")
    create_severity_pie_chart(threats)
    create_source_country_bar(threats)
    create_attack_type_chart(threats)
    create_hourly_trend(threats)
    create_block_rate_gauge(threats)
    create_dashboard_summary(threats)
    
    print("\nAll visualizations generated successfully!")
