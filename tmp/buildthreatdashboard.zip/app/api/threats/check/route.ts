import { checkIPReputation, getThreatIntelligence } from "@/lib/threat-api"

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { type, query } = body

    if (type === "ip") {
      const data = await checkIPReputation(query)
      return Response.json({ success: true, data })
    } else if (type === "threat-intel") {
      const data = await getThreatIntelligence(query)
      return Response.json({ success: true, data })
    }

    return Response.json({ success: false, error: "Invalid request type" })
  } catch (error) {
    console.error("API route error:", error)
    return Response.json({ success: false, error: "Failed to fetch threat data" }, { status: 500 })
  }
}
