"use client"

import { useState } from "react"
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from "@/components/ui/sheet"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Slider } from "@/components/ui/slider"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Separator } from "@/components/ui/separator"
import { Sun, Moon, Monitor, Bell, RefreshCw, Layout, AlertTriangle, Shield, Volume2, Mail } from "lucide-react"

interface SettingsPanelProps {
  isOpen: boolean
  onClose: () => void
  settings: DashboardSettings
  onSettingsChange: (settings: DashboardSettings) => void
}

export interface DashboardSettings {
  theme: "light" | "dark" | "system"
  refreshInterval: number
  notifications: {
    critical: boolean
    high: boolean
    medium: boolean
    low: boolean
    sound: boolean
    email: boolean
  }
  layout: "default" | "compact" | "expanded"
  alertThresholds: {
    criticalCount: number
    highCount: number
    blockedPerMinute: number
  }
}

export const defaultSettings: DashboardSettings = {
  theme: "dark",
  refreshInterval: 4,
  notifications: {
    critical: true,
    high: true,
    medium: false,
    low: false,
    sound: true,
    email: false,
  },
  layout: "default",
  alertThresholds: {
    criticalCount: 10,
    highCount: 25,
    blockedPerMinute: 50,
  },
}

export function SettingsPanel({ isOpen, onClose, settings, onSettingsChange }: SettingsPanelProps) {
  const [localSettings, setLocalSettings] = useState<DashboardSettings>(settings)

  const updateSettings = (updates: Partial<DashboardSettings>) => {
    const newSettings = { ...localSettings, ...updates }
    setLocalSettings(newSettings)
    onSettingsChange(newSettings)
  }

  const updateNotifications = (key: keyof DashboardSettings["notifications"], value: boolean) => {
    updateSettings({
      notifications: { ...localSettings.notifications, [key]: value },
    })
  }

  const updateThresholds = (key: keyof DashboardSettings["alertThresholds"], value: number) => {
    updateSettings({
      alertThresholds: { ...localSettings.alertThresholds, [key]: value },
    })
  }

  return (
    <Sheet open={isOpen} onOpenChange={onClose}>
      <SheetContent className="w-full sm:max-w-md overflow-y-auto">
        <SheetHeader>
          <SheetTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5 text-primary" />
            Dashboard Settings
          </SheetTitle>
          <SheetDescription>Configure your threat monitoring preferences</SheetDescription>
        </SheetHeader>

        <div className="mt-6 space-y-6">
          {/* Theme Selection */}
          <div className="space-y-3">
            <Label className="text-sm font-medium flex items-center gap-2">
              <Monitor className="h-4 w-4" />
              Appearance
            </Label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { value: "light", icon: Sun, label: "Light" },
                { value: "dark", icon: Moon, label: "Dark" },
                { value: "system", icon: Monitor, label: "System" },
              ].map(({ value, icon: Icon, label }) => (
                <Button
                  key={value}
                  variant={localSettings.theme === value ? "default" : "outline"}
                  size="sm"
                  className="flex flex-col gap-1 h-auto py-3"
                  onClick={() => updateSettings({ theme: value as DashboardSettings["theme"] })}
                >
                  <Icon className="h-4 w-4" />
                  <span className="text-xs">{label}</span>
                </Button>
              ))}
            </div>
          </div>

          <Separator />

          {/* Refresh Interval */}
          <div className="space-y-3">
            <Label className="text-sm font-medium flex items-center gap-2">
              <RefreshCw className="h-4 w-4" />
              Data Refresh Interval
            </Label>
            <Select
              value={localSettings.refreshInterval.toString()}
              onValueChange={(v) => updateSettings({ refreshInterval: Number.parseInt(v) })}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="2">2 seconds (Real-time)</SelectItem>
                <SelectItem value="4">4 seconds (Default)</SelectItem>
                <SelectItem value="10">10 seconds (Balanced)</SelectItem>
                <SelectItem value="30">30 seconds (Low bandwidth)</SelectItem>
                <SelectItem value="60">1 minute (Minimal)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Separator />

          {/* Notification Preferences */}
          <div className="space-y-4">
            <Label className="text-sm font-medium flex items-center gap-2">
              <Bell className="h-4 w-4" />
              Notification Preferences
            </Label>

            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-red-500" />
                  <span className="text-sm">Critical Alerts</span>
                </div>
                <Switch
                  checked={localSettings.notifications.critical}
                  onCheckedChange={(v) => updateNotifications("critical", v)}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-orange-500" />
                  <span className="text-sm">High Severity</span>
                </div>
                <Switch
                  checked={localSettings.notifications.high}
                  onCheckedChange={(v) => updateNotifications("high", v)}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-yellow-500" />
                  <span className="text-sm">Medium Severity</span>
                </div>
                <Switch
                  checked={localSettings.notifications.medium}
                  onCheckedChange={(v) => updateNotifications("medium", v)}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-blue-500" />
                  <span className="text-sm">Low Severity</span>
                </div>
                <Switch
                  checked={localSettings.notifications.low}
                  onCheckedChange={(v) => updateNotifications("low", v)}
                />
              </div>

              <Separator className="my-2" />

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Volume2 className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm">Sound Alerts</span>
                </div>
                <Switch
                  checked={localSettings.notifications.sound}
                  onCheckedChange={(v) => updateNotifications("sound", v)}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Mail className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm">Email Notifications</span>
                </div>
                <Switch
                  checked={localSettings.notifications.email}
                  onCheckedChange={(v) => updateNotifications("email", v)}
                />
              </div>
            </div>
          </div>

          <Separator />

          {/* Dashboard Layout */}
          <div className="space-y-3">
            <Label className="text-sm font-medium flex items-center gap-2">
              <Layout className="h-4 w-4" />
              Dashboard Layout
            </Label>
            <Select
              value={localSettings.layout}
              onValueChange={(v) => updateSettings({ layout: v as DashboardSettings["layout"] })}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="default">Default (Balanced)</SelectItem>
                <SelectItem value="compact">Compact (More data)</SelectItem>
                <SelectItem value="expanded">Expanded (Larger charts)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Separator />

          {/* Alert Thresholds */}
          <div className="space-y-4">
            <Label className="text-sm font-medium flex items-center gap-2">
              <AlertTriangle className="h-4 w-4" />
              Alert Thresholds
            </Label>

            <div className="space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Critical Alert Threshold</span>
                  <span className="text-red-500 font-medium">
                    {localSettings.alertThresholds.criticalCount} threats
                  </span>
                </div>
                <Slider
                  value={[localSettings.alertThresholds.criticalCount]}
                  onValueChange={([v]) => updateThresholds("criticalCount", v)}
                  min={1}
                  max={50}
                  step={1}
                  className="w-full"
                />
              </div>

              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>High Alert Threshold</span>
                  <span className="text-orange-500 font-medium">{localSettings.alertThresholds.highCount} threats</span>
                </div>
                <Slider
                  value={[localSettings.alertThresholds.highCount]}
                  onValueChange={([v]) => updateThresholds("highCount", v)}
                  min={5}
                  max={100}
                  step={5}
                />
              </div>

              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Blocked/min Warning</span>
                  <span className="text-yellow-500 font-medium">
                    {localSettings.alertThresholds.blockedPerMinute}/min
                  </span>
                </div>
                <Slider
                  value={[localSettings.alertThresholds.blockedPerMinute]}
                  onValueChange={([v]) => updateThresholds("blockedPerMinute", v)}
                  min={10}
                  max={200}
                  step={10}
                />
              </div>
            </div>
          </div>

          <Separator />

          {/* Reset Button */}
          <Button
            variant="outline"
            className="w-full bg-transparent"
            onClick={() => {
              setLocalSettings(defaultSettings)
              onSettingsChange(defaultSettings)
            }}
          >
            Reset to Defaults
          </Button>
        </div>
      </SheetContent>
    </Sheet>
  )
}
