"use client"

import { useState, useEffect } from "react"
import { generateRiskMatrix, type RiskCell } from "@/lib/threat-data"
import { Shield, TrendingUp, TrendingDown, Minus } from "lucide-react"

export function RiskMatrix() {
  const [cells, setCells] = useState<RiskCell[]>([])
  const [selectedCell, setSelectedCell] = useState<RiskCell | null>(null)

  useEffect(() => {
    setCells(generateRiskMatrix())
  }, [])

  const getRiskLevel = (score: number) => {
    if (score >= 80) return { label: "Critical", color: "bg-red-500", text: "text-red-600", ring: "ring-red-200" }
    if (score >= 60) return { label: "High", color: "bg-orange-500", text: "text-orange-600", ring: "ring-orange-200" }
    if (score >= 40) return { label: "Medium", color: "bg-amber-500", text: "text-amber-600", ring: "ring-amber-200" }
    if (score >= 20)
      return { label: "Low", color: "bg-emerald-500", text: "text-emerald-600", ring: "ring-emerald-200" }
    return { label: "Safe", color: "bg-sky-500", text: "text-sky-600", ring: "ring-sky-200" }
  }

  const categories = [
    { name: "Network", icon: "🌐" },
    { name: "Endpoint", icon: "💻" },
    { name: "Cloud", icon: "☁️" },
    { name: "Identity", icon: "🔐" },
    { name: "Data", icon: "📊" },
  ]

  const avgScore = cells.length > 0 ? Math.round(cells.reduce((sum, c) => sum + c.score, 0) / cells.length) : 0
  const overallRisk = getRiskLevel(avgScore)

  return (
    <div className="rounded-xl border border-border bg-card p-5 shadow-sm">
      <div className="flex items-center justify-between mb-5">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-lg bg-primary/10">
            <Shield className="h-4 w-4 text-primary" />
          </div>
          <span className="text-sm font-medium">Security Posture</span>
        </div>
        <div className={`px-2.5 py-1 rounded-full text-xs font-medium ${overallRisk.color} text-white`}>
          {avgScore}% Risk
        </div>
      </div>

      {/* Category Cards */}
      <div className="space-y-2">
        {categories.map((category, idx) => {
          const categoryCells = cells.filter((c) => c.category === category.name)
          const categoryAvg =
            categoryCells.length > 0
              ? Math.round(categoryCells.reduce((sum, c) => sum + c.score, 0) / categoryCells.length)
              : 0
          const risk = getRiskLevel(categoryAvg)
          const trend = categoryCells[0]?.trend

          return (
            <div
              key={category.name}
              onClick={() => setSelectedCell(categoryCells[0] || null)}
              className={`
                flex items-center justify-between p-3 rounded-lg cursor-pointer
                transition-all duration-200 hover:scale-[1.02] animate-fade-in-up
                ${
                  selectedCell?.category === category.name
                    ? `ring-2 ${risk.ring} bg-gradient-to-r from-white to-${risk.color}/5`
                    : "bg-secondary/50 hover:bg-secondary"
                }
              `}
              style={{ animationDelay: `${idx * 0.05}s` }}
            >
              <div className="flex items-center gap-3">
                <span className="text-lg">{category.icon}</span>
                <div>
                  <p className="text-sm font-medium">{category.name}</p>
                  <p className="text-xs text-muted-foreground">{categoryCells.length} assets monitored</p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <div className="flex items-center gap-1">
                  {trend === "up" && <TrendingUp className="h-3 w-3 text-red-500" />}
                  {trend === "down" && <TrendingDown className="h-3 w-3 text-emerald-500" />}
                  {trend === "stable" && <Minus className="h-3 w-3 text-muted-foreground" />}
                </div>

                {/* Progress bar */}
                <div className="w-20 h-2 bg-secondary rounded-full overflow-hidden">
                  <div
                    className={`h-full ${risk.color} transition-all duration-500`}
                    style={{ width: `${categoryAvg}%` }}
                  />
                </div>

                <span className={`text-sm font-semibold ${risk.text} w-8 text-right`}>{categoryAvg}</span>
              </div>
            </div>
          )
        })}
      </div>

      {/* Selected Details */}
      {selectedCell && (
        <div className="mt-4 p-3 rounded-lg bg-gradient-to-r from-primary/5 to-transparent border border-primary/20 animate-slide-in-right">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs text-muted-foreground">Selected Asset</p>
              <p className="font-medium">
                {selectedCell.category} - {selectedCell.asset}
              </p>
            </div>
            <div className="text-right">
              <p className="text-xs text-muted-foreground">Risk Score</p>
              <p className={`text-lg font-bold ${getRiskLevel(selectedCell.score).text}`}>{selectedCell.score}</p>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
