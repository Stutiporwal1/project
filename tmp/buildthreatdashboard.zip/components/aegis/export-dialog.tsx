"use client"

import { useState } from "react"
import { X, Download, FileText, FileSpreadsheet, FileCode, Check, Loader2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"

interface ExportDialogProps {
  isOpen: boolean
  onClose: () => void
}

const exportFormats = [
  { id: "csv", label: "CSV", icon: FileSpreadsheet, description: "Spreadsheet format" },
  { id: "json", label: "JSON", icon: FileCode, description: "Structured data" },
  { id: "pdf", label: "PDF Report", icon: FileText, description: "Formatted report" },
]

const dataOptions = [
  { id: "threats", label: "Threat Events", description: "All detected threats" },
  { id: "blocked", label: "Blocked Attacks", description: "Successfully blocked attempts" },
  { id: "analytics", label: "Analytics Data", description: "Statistical analysis" },
  { id: "predictions", label: "AI Predictions", description: "ML model predictions" },
]

export function ExportDialog({ isOpen, onClose }: ExportDialogProps) {
  const [selectedFormat, setSelectedFormat] = useState("csv")
  const [selectedData, setSelectedData] = useState<string[]>(["threats", "blocked"])
  const [isExporting, setIsExporting] = useState(false)
  const [exportComplete, setExportComplete] = useState(false)

  const toggleDataOption = (id: string) => {
    setSelectedData((prev) => (prev.includes(id) ? prev.filter((d) => d !== id) : [...prev, id]))
  }

  const handleExport = async () => {
    setIsExporting(true)
    setExportComplete(false)

    // Simulate export
    await new Promise((resolve) => setTimeout(resolve, 2000))

    setIsExporting(false)
    setExportComplete(true)

    // Reset after showing success
    setTimeout(() => {
      setExportComplete(false)
    }, 3000)
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={onClose} />

      <div className="relative w-full max-w-md bg-card rounded-2xl shadow-2xl border border-border overflow-hidden animate-fade-in-up">
        <div className="flex items-center justify-between p-4 border-b border-border">
          <div className="flex items-center gap-2">
            <Download className="h-5 w-5 text-primary" />
            <h2 className="text-lg font-semibold">Export Data</h2>
          </div>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="h-5 w-5" />
          </Button>
        </div>

        <div className="p-6 space-y-6">
          {/* Format Selection */}
          <div className="space-y-3">
            <Label>Export Format</Label>
            <div className="grid grid-cols-3 gap-2">
              {exportFormats.map((format) => (
                <button
                  key={format.id}
                  onClick={() => setSelectedFormat(format.id)}
                  className={`flex flex-col items-center gap-2 p-4 rounded-lg border transition-colors ${
                    selectedFormat === format.id
                      ? "bg-primary/10 border-primary text-primary"
                      : "bg-background border-border hover:bg-muted"
                  }`}
                >
                  <format.icon className="h-6 w-6" />
                  <span className="text-sm font-medium">{format.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Data Selection */}
          <div className="space-y-3">
            <Label>Data to Export</Label>
            <div className="space-y-2">
              {dataOptions.map((option) => (
                <div
                  key={option.id}
                  className="flex items-center gap-3 p-3 rounded-lg border border-border hover:bg-muted/50 transition-colors"
                >
                  <Checkbox
                    id={option.id}
                    checked={selectedData.includes(option.id)}
                    onCheckedChange={() => toggleDataOption(option.id)}
                  />
                  <div className="flex-1">
                    <label htmlFor={option.id} className="text-sm font-medium cursor-pointer">
                      {option.label}
                    </label>
                    <p className="text-xs text-muted-foreground">{option.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Export Status */}
          {exportComplete && (
            <div className="flex items-center gap-2 p-3 bg-emerald-50 text-emerald-700 rounded-lg border border-emerald-200">
              <Check className="h-5 w-5" />
              <span className="text-sm font-medium">Export complete! Download started.</span>
            </div>
          )}

          {/* Actions */}
          <div className="flex gap-3">
            <Button variant="outline" onClick={onClose} className="flex-1 bg-transparent">
              Cancel
            </Button>
            <Button onClick={handleExport} disabled={isExporting || selectedData.length === 0} className="flex-1">
              {isExporting ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Exporting...
                </>
              ) : (
                <>
                  <Download className="h-4 w-4 mr-2" />
                  Export
                </>
              )}
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
