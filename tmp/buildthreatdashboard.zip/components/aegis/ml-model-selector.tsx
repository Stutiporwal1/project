"use client"

import { useState } from "react"
import { Brain, Check, Zap, Target, TrendingUp } from "lucide-react"
import { cn } from "@/lib/utils"

interface MLModel {
  id: string
  name: string
  type: string
  accuracy: number
  latency: number
  description: string
}

const models: MLModel[] = [
  {
    id: "dnn",
    name: "Deep Neural Network",
    type: "Deep Learning",
    accuracy: 94.7,
    latency: 45,
    description: "Multi-layer neural network for complex pattern detection",
  },
  {
    id: "rf",
    name: "Random Forest",
    type: "Ensemble",
    accuracy: 91.3,
    latency: 12,
    description: "Fast ensemble method for balanced performance",
  },
  {
    id: "xgb",
    name: "XGBoost Classifier",
    type: "Gradient Boosting",
    accuracy: 92.8,
    latency: 18,
    description: "Optimized boosting for high-dimensional data",
  },
  {
    id: "bert",
    name: "BERT Transformer",
    type: "NLP/Transformer",
    accuracy: 96.2,
    latency: 120,
    description: "State-of-the-art for text-based threat analysis",
  },
  {
    id: "iforest",
    name: "Isolation Forest",
    type: "Anomaly Detection",
    accuracy: 88.5,
    latency: 8,
    description: "Unsupervised anomaly detection for unknown threats",
  },
  {
    id: "hybrid",
    name: "Hybrid Ensemble",
    type: "Multi-Model",
    accuracy: 97.1,
    latency: 85,
    description: "Combines multiple models for maximum accuracy",
  },
]

export function MLModelSelector() {
  const [selectedModel, setSelectedModel] = useState<string>("dnn")

  return (
    <div className="rounded-xl border border-border bg-card p-4">
      <div className="flex items-center gap-2 mb-4">
        <Brain className="h-5 w-5 text-primary" />
        <h3 className="font-semibold">AI/ML Model Selection</h3>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
        {models.map((model, idx) => (
          <button
            key={model.id}
            onClick={() => setSelectedModel(model.id)}
            className={cn(
              "relative p-3 rounded-lg border text-left transition-all duration-300 animate-fade-in-up",
              selectedModel === model.id
                ? "border-primary bg-primary/5 shadow-md"
                : "border-border bg-background hover:border-primary/50 hover:bg-muted/50",
            )}
            style={{ animationDelay: `${idx * 0.05}s` }}
          >
            {selectedModel === model.id && (
              <div className="absolute top-2 right-2">
                <div className="p-1 rounded-full bg-primary text-white">
                  <Check className="h-3 w-3" />
                </div>
              </div>
            )}

            <div className="mb-2">
              <h4 className="font-medium text-sm leading-tight">{model.name}</h4>
              <p className="text-xs text-muted-foreground">{model.type}</p>
            </div>

            <div className="flex items-center gap-3 text-xs">
              <div className="flex items-center gap-1">
                <Target className="h-3 w-3 text-emerald-500" />
                <span className="font-mono">{model.accuracy}%</span>
              </div>
              <div className="flex items-center gap-1">
                <Zap className="h-3 w-3 text-amber-500" />
                <span className="font-mono">{model.latency}ms</span>
              </div>
            </div>
          </button>
        ))}
      </div>

      {/* Selected model details */}
      {selectedModel && (
        <div className="mt-4 p-3 rounded-lg bg-muted/50 border border-border animate-fade-in-up">
          <div className="flex items-start justify-between">
            <div>
              <h4 className="font-medium">{models.find((m) => m.id === selectedModel)?.name}</h4>
              <p className="text-sm text-muted-foreground mt-1">
                {models.find((m) => m.id === selectedModel)?.description}
              </p>
            </div>
            <div className="flex items-center gap-1 px-2 py-1 rounded-full bg-emerald-100 text-emerald-700 text-xs">
              <TrendingUp className="h-3 w-3" />
              Active
            </div>
          </div>

          <div className="mt-3 grid grid-cols-3 gap-3 text-center">
            <div className="p-2 rounded-lg bg-background">
              <p className="text-lg font-bold text-primary">{models.find((m) => m.id === selectedModel)?.accuracy}%</p>
              <p className="text-xs text-muted-foreground">Accuracy</p>
            </div>
            <div className="p-2 rounded-lg bg-background">
              <p className="text-lg font-bold text-amber-500">
                {models.find((m) => m.id === selectedModel)?.latency}ms
              </p>
              <p className="text-xs text-muted-foreground">Latency</p>
            </div>
            <div className="p-2 rounded-lg bg-background">
              <p className="text-lg font-bold text-emerald-500">99.9%</p>
              <p className="text-xs text-muted-foreground">Uptime</p>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
