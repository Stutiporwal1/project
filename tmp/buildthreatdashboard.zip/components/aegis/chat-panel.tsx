"use client"

import { useState, useRef, useEffect } from "react"
import { X, MessageSquare, Send, Bot, User } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

interface ChatPanelProps {
  isOpen: boolean
  onClose: () => void
}

interface Message {
  id: string
  role: "user" | "assistant"
  content: string
  timestamp: Date
}

const initialMessages: Message[] = [
  {
    id: "1",
    role: "assistant",
    content:
      "Hello! I'm your AEGIS Security Assistant. I can help you analyze threats, explain security events, and provide recommendations. How can I help you today?",
    timestamp: new Date(),
  },
]

const quickResponses = [
  "What are the current critical threats?",
  "Explain the latest DDoS attack",
  "Show me blocked attack trends",
  "Recommend security improvements",
]

export function ChatPanel({ isOpen, onClose }: ChatPanelProps) {
  const [messages, setMessages] = useState<Message[]>(initialMessages)
  const [input, setInput] = useState("")
  const [isTyping, setIsTyping] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const generateResponse = (userMessage: string): string => {
    const lowerMessage = userMessage.toLowerCase()

    if (lowerMessage.includes("critical") || lowerMessage.includes("threat")) {
      return "Currently monitoring 12 critical threats. The most significant is a coordinated DDoS attack originating from Eastern Europe, targeting your API endpoints. I recommend enabling enhanced rate limiting and geographic blocking for suspicious regions."
    }
    if (lowerMessage.includes("ddos")) {
      return "The latest DDoS attack was detected 15 minutes ago. It peaked at 2.3 Gbps and originated from a botnet spanning 47 countries. Our systems automatically mitigated the attack by implementing traffic scrubbing and CDN failover. No service disruption occurred."
    }
    if (lowerMessage.includes("blocked") || lowerMessage.includes("trends")) {
      return "Over the past 24 hours, we've blocked 892 attacks. The breakdown is: 45% DDoS attempts, 28% SQL injection, 15% XSS attacks, and 12% credential stuffing. Attack volume is up 23% compared to last week, primarily during business hours."
    }
    if (lowerMessage.includes("recommend") || lowerMessage.includes("improve")) {
      return "Based on current threat patterns, I recommend: 1) Implementing additional rate limiting on login endpoints, 2) Enabling MFA for all admin accounts, 3) Updating WAF rules to block the latest SQL injection patterns, and 4) Scheduling a penetration test for next month."
    }

    return "I understand you're asking about security. Could you be more specific? I can help with threat analysis, attack explanations, trend reports, or security recommendations."
  }

  const handleSend = async () => {
    if (!input.trim()) return

    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: input,
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setIsTyping(true)

    // Simulate AI thinking
    await new Promise((resolve) => setTimeout(resolve, 1500))

    const response = generateResponse(input)
    const assistantMessage: Message = {
      id: (Date.now() + 1).toString(),
      role: "assistant",
      content: response,
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, assistantMessage])
    setIsTyping(false)
  }

  const handleQuickResponse = (text: string) => {
    setInput(text)
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-y-0 right-0 z-50 w-full max-w-md flex flex-col">
      <div className="absolute inset-0 bg-black/20 backdrop-blur-sm -z-10" onClick={onClose} />

      <div className="flex flex-col h-full bg-card border-l border-border shadow-2xl animate-slide-in-right">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-border">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-primary/10 rounded-lg">
              <MessageSquare className="h-5 w-5 text-primary" />
            </div>
            <div>
              <h2 className="font-semibold">Security Assistant</h2>
              <p className="text-xs text-muted-foreground">AI-powered threat analysis</p>
            </div>
          </div>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="h-5 w-5" />
          </Button>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((message) => (
            <div key={message.id} className={`flex gap-3 ${message.role === "user" ? "flex-row-reverse" : ""}`}>
              <div
                className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center ${
                  message.role === "user" ? "bg-primary" : "bg-muted"
                }`}
              >
                {message.role === "user" ? (
                  <User className="h-4 w-4 text-primary-foreground" />
                ) : (
                  <Bot className="h-4 w-4 text-muted-foreground" />
                )}
              </div>
              <div
                className={`max-w-[80%] rounded-2xl px-4 py-3 ${
                  message.role === "user" ? "bg-primary text-primary-foreground" : "bg-muted"
                }`}
              >
                <p className="text-sm">{message.content}</p>
                <p className="text-[10px] opacity-60 mt-1">
                  {message.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                </p>
              </div>
            </div>
          ))}

          {isTyping && (
            <div className="flex gap-3">
              <div className="flex-shrink-0 w-8 h-8 rounded-full bg-muted flex items-center justify-center">
                <Bot className="h-4 w-4 text-muted-foreground" />
              </div>
              <div className="bg-muted rounded-2xl px-4 py-3">
                <div className="flex gap-1">
                  <span className="w-2 h-2 bg-muted-foreground/40 rounded-full animate-bounce" />
                  <span className="w-2 h-2 bg-muted-foreground/40 rounded-full animate-bounce [animation-delay:0.1s]" />
                  <span className="w-2 h-2 bg-muted-foreground/40 rounded-full animate-bounce [animation-delay:0.2s]" />
                </div>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Quick Responses */}
        <div className="px-4 pb-2">
          <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
            {quickResponses.map((text, idx) => (
              <button
                key={idx}
                onClick={() => handleQuickResponse(text)}
                className="flex-shrink-0 px-3 py-1.5 text-xs bg-muted hover:bg-muted/80 rounded-full transition-colors"
              >
                {text}
              </button>
            ))}
          </div>
        </div>

        {/* Input */}
        <div className="p-4 border-t border-border">
          <form
            onSubmit={(e) => {
              e.preventDefault()
              handleSend()
            }}
            className="flex gap-2"
          >
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask about threats, attacks, or security..."
              className="flex-1"
            />
            <Button type="submit" size="icon" disabled={!input.trim() || isTyping}>
              <Send className="h-4 w-4" />
            </Button>
          </form>
        </div>
      </div>
    </div>
  )
}
