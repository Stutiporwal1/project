"use client"

import { Activity, ShieldCheck, AlertTriangle, Eye } from "lucide-react"
import { useEffect, useState } from "react"

interface StatsBarProps {
  threats: number
  blocked: number
  critical: number
  monitoring: number
}

function AnimatedNumber({ value, color }: { value: number; color: string }) {
  const [displayValue, setDisplayValue] = useState(value)

  useEffect(() => {
    const diff = value - displayValue
    if (diff === 0) return

    const steps = 10
    const increment = diff / steps
    let current = displayValue

    const interval = setInterval(() => {
      current += increment
      if ((diff > 0 && current >= value) || (diff < 0 && current <= value)) {
        setDisplayValue(value)
        clearInterval(interval)
      } else {
        setDisplayValue(Math.round(current))
      }
    }, 30)

    return () => clearInterval(interval)
  }, [value, displayValue])

  return (
    <span className={`font-mono text-2xl font-bold ${color} animate-counter`}>{displayValue.toLocaleString()}</span>
  )
}

export function StatsBar({ threats, blocked, critical, monitoring }: StatsBarProps) {
  const stats = [
    {
      label: "Active Threats",
      value: threats,
      icon: <Activity className="h-5 w-5" />,
      color: "text-orange-500",
      bgColor: "bg-orange-50",
      borderColor: "border-orange-200",
    },
    {
      label: "Blocked",
      value: blocked,
      icon: <ShieldCheck className="h-5 w-5" />,
      color: "text-emerald-500",
      bgColor: "bg-emerald-50",
      borderColor: "border-emerald-200",
    },
    {
      label: "Critical",
      value: critical,
      icon: <AlertTriangle className="h-5 w-5" />,
      color: "text-red-500",
      bgColor: "bg-red-50",
      borderColor: "border-red-200",
    },
    {
      label: "Monitoring",
      value: monitoring,
      icon: <Eye className="h-5 w-5" />,
      color: "text-primary",
      bgColor: "bg-primary/5",
      borderColor: "border-primary/20",
    },
  ]

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      {stats.map((stat, idx) => (
        <div
          key={stat.label}
          className={`
            relative overflow-hidden rounded-xl border ${stat.borderColor} ${stat.bgColor} p-4
            transition-all duration-300 hover:shadow-lg hover:scale-[1.02]
            animate-fade-in-up
          `}
          style={{ animationDelay: `${idx * 0.1}s` }}
        >
          {/* Shimmer effect */}
          <div className="absolute inset-0 animate-shimmer opacity-50" />

          <div className="relative flex items-start justify-between">
            <div>
              <AnimatedNumber value={stat.value} color={stat.color} />
              <p className="text-sm text-muted-foreground mt-1">{stat.label}</p>
            </div>
            <div className={`p-2 rounded-lg ${stat.bgColor} ${stat.color}`}>{stat.icon}</div>
          </div>

          {/* Progress indicator */}
          <div className="absolute bottom-0 left-0 right-0 h-1 bg-white/50">
            <div
              className={`h-full ${stat.color.replace("text-", "bg-")} transition-all duration-1000`}
              style={{ width: `${Math.min(100, (stat.value / 100) * 100)}%` }}
            />
          </div>
        </div>
      ))}
    </div>
  )
}
