"use client"

import { useState, useEffect } from "react"
import { Sparkles, TrendingUp, TrendingDown, Clock } from "lucide-react"

interface Prediction {
  label: string
  probability: number
  trend: "up" | "down"
  icon: string
}

export function PredictionCard() {
  const [predictions, setPredictions] = useState<Prediction[]>([
    { label: "DDoS Attack", probability: 73, trend: "up", icon: "🌊" },
    { label: "Ransomware", probability: 45, trend: "down", icon: "🔒" },
    { label: "Data Breach", probability: 28, trend: "up", icon: "📤" },
  ])
  const [confidence, setConfidence] = useState(94.2)

  useEffect(() => {
    const interval = setInterval(() => {
      setPredictions((prev) =>
        prev.map((p) => ({
          ...p,
          probability: Math.max(5, Math.min(95, p.probability + (Math.random() - 0.5) * 8)),
        })),
      )
      setConfidence((prev) => Math.max(85, Math.min(99, prev + (Math.random() - 0.5) * 2)))
    }, 5000)
    return () => clearInterval(interval)
  }, [])

  const getProbabilityColor = (prob: number) => {
    if (prob > 60) return { bg: "bg-red-100", text: "text-red-700", bar: "bg-red-500" }
    if (prob > 30) return { bg: "bg-amber-100", text: "text-amber-700", bar: "bg-amber-500" }
    return { bg: "bg-emerald-100", text: "text-emerald-700", bar: "bg-emerald-500" }
  }

  return (
    <div className="rounded-xl border border-border bg-card p-5 shadow-sm">
      <div className="flex items-center justify-between mb-5">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-lg bg-primary/10">
            <Sparkles className="h-4 w-4 text-primary" />
          </div>
          <span className="text-sm font-medium">AI Predictions</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1 px-2 py-0.5 rounded-md bg-muted text-muted-foreground text-xs">
            <Clock className="h-3 w-3" />
            Next 24h
          </div>
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-primary/10 text-primary text-xs font-medium">
            <div className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
            {confidence.toFixed(1)}%
          </div>
        </div>
      </div>

      <div className="space-y-4">
        {predictions.map((pred, idx) => {
          const colors = getProbabilityColor(pred.probability)
          return (
            <div
              key={pred.label}
              className={`
                p-3 rounded-lg ${colors.bg} transition-all duration-300 hover:scale-[1.02]
                animate-fade-in-up
              `}
              style={{ animationDelay: `${idx * 0.1}s` }}
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <span className="text-lg">{pred.icon}</span>
                  <span className="text-sm font-medium">{pred.label}</span>
                </div>
                <div className="flex items-center gap-2">
                  {pred.trend === "up" ? (
                    <TrendingUp className="h-4 w-4 text-red-500" />
                  ) : (
                    <TrendingDown className="h-4 w-4 text-emerald-500" />
                  )}
                  <span className={`font-mono font-bold ${colors.text}`}>{pred.probability.toFixed(0)}%</span>
                </div>
              </div>
              <div className="h-2 bg-white/60 rounded-full overflow-hidden">
                <div
                  className={`h-full ${colors.bar} rounded-full transition-all duration-700`}
                  style={{ width: `${pred.probability}%` }}
                />
              </div>
            </div>
          )
        })}
      </div>

      <div className="mt-5 p-3 rounded-lg bg-gradient-to-r from-primary/5 to-transparent border border-primary/20">
        <div className="flex items-center gap-2 text-xs text-muted-foreground mb-1">
          <Clock className="h-3 w-3" />
          Next Attack Window
        </div>
        <div className="font-mono text-xl font-bold text-foreground">14:00 - 18:00 UTC</div>
        <div className="text-xs text-muted-foreground mt-1">High probability period based on historical data</div>
      </div>
    </div>
  )
}
