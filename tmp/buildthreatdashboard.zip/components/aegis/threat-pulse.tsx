"use client"

import { useEffect, useState, useRef } from "react"
import { generatePulseData, type PulseData } from "@/lib/threat-data"
import { Activity, Zap } from "lucide-react"

export function ThreatPulse() {
  const [data, setData] = useState<PulseData[]>([])
  const [currentValue, setCurrentValue] = useState(0)
  const [isAnomalyFlash, setIsAnomalyFlash] = useState(false)
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    setData(generatePulseData(60))
  }, [])

  useEffect(() => {
    const interval = setInterval(() => {
      setData((prev) => {
        const isAnomaly = Math.random() > 0.95
        const newPoint: PulseData = {
          timestamp: new Date(),
          value: 50 + Math.sin(Date.now() / 1000) * 20 + (Math.random() - 0.5) * 15,
          anomaly: isAnomaly,
        }
        setCurrentValue(Math.round(newPoint.value))
        if (isAnomaly) {
          setIsAnomalyFlash(true)
          setTimeout(() => setIsAnomalyFlash(false), 500)
        }
        return [...prev.slice(1), newPoint]
      })
    }, 1000)
    return () => clearInterval(interval)
  }, [])

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas || data.length === 0) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const dpr = window.devicePixelRatio || 1
    const rect = canvas.getBoundingClientRect()
    canvas.width = rect.width * dpr
    canvas.height = rect.height * dpr
    ctx.scale(dpr, dpr)

    ctx.clearRect(0, 0, rect.width, rect.height)

    // Draw gradient fill
    const gradient = ctx.createLinearGradient(0, 0, 0, rect.height)
    gradient.addColorStop(0, "rgba(99, 102, 241, 0.2)")
    gradient.addColorStop(1, "rgba(99, 102, 241, 0)")

    ctx.beginPath()
    const step = rect.width / (data.length - 1)
    data.forEach((point, i) => {
      const x = i * step
      const y = rect.height - (point.value / 100) * rect.height * 0.8 - rect.height * 0.1
      if (i === 0) ctx.moveTo(x, y)
      else ctx.lineTo(x, y)
    })
    ctx.lineTo(rect.width, rect.height)
    ctx.lineTo(0, rect.height)
    ctx.closePath()
    ctx.fillStyle = gradient
    ctx.fill()

    // Draw pulse line
    ctx.beginPath()
    ctx.strokeStyle = "#6366f1"
    ctx.lineWidth = 2.5
    ctx.lineCap = "round"
    ctx.lineJoin = "round"

    data.forEach((point, i) => {
      const x = i * step
      const y = rect.height - (point.value / 100) * rect.height * 0.8 - rect.height * 0.1
      if (i === 0) ctx.moveTo(x, y)
      else ctx.lineTo(x, y)
    })
    ctx.stroke()

    // Draw anomaly points with glow
    data.forEach((point, i) => {
      if (point.anomaly) {
        const x = i * step
        const y = rect.height - (point.value / 100) * rect.height * 0.8 - rect.height * 0.1

        // Glow effect
        ctx.beginPath()
        ctx.arc(x, y, 12, 0, Math.PI * 2)
        const glow = ctx.createRadialGradient(x, y, 0, x, y, 12)
        glow.addColorStop(0, "rgba(239, 68, 68, 0.5)")
        glow.addColorStop(1, "rgba(239, 68, 68, 0)")
        ctx.fillStyle = glow
        ctx.fill()

        // Point
        ctx.beginPath()
        ctx.arc(x, y, 5, 0, Math.PI * 2)
        ctx.fillStyle = "#ef4444"
        ctx.fill()
        ctx.strokeStyle = "#fff"
        ctx.lineWidth = 2
        ctx.stroke()
      }
    })

    // Draw current value indicator
    const lastPoint = data[data.length - 1]
    if (lastPoint) {
      const x = rect.width
      const y = rect.height - (lastPoint.value / 100) * rect.height * 0.8 - rect.height * 0.1
      ctx.beginPath()
      ctx.arc(x, y, 6, 0, Math.PI * 2)
      ctx.fillStyle = "#6366f1"
      ctx.fill()
      ctx.strokeStyle = "#fff"
      ctx.lineWidth = 2
      ctx.stroke()
    }
  }, [data])

  const anomalyCount = data.filter((d) => d.anomaly).length

  return (
    <div
      className={`
      rounded-xl border bg-card p-5 shadow-sm transition-all duration-300
      ${isAnomalyFlash ? "border-red-300 shadow-red-100" : "border-border"}
    `}
    >
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-lg bg-primary/10">
            <Activity className="h-4 w-4 text-primary" />
          </div>
          <span className="text-sm font-medium">System Pulse</span>
        </div>
        <div className="flex items-center gap-4">
          {anomalyCount > 0 && (
            <div className="flex items-center gap-1.5 px-2 py-1 rounded-full bg-red-50 text-red-600 text-xs font-medium animate-fade-in-up">
              <Zap className="h-3 w-3" />
              {anomalyCount} spikes
            </div>
          )}
          <div className="text-right">
            <span className="font-mono text-3xl font-bold text-primary">{currentValue}</span>
            <span className="text-xs text-muted-foreground ml-1">bpm</span>
          </div>
        </div>
      </div>

      <canvas ref={canvasRef} className="w-full h-28 rounded-lg" />

      <div className="flex justify-between mt-3 text-xs text-muted-foreground">
        <span>2 min ago</span>
        <span className="flex items-center gap-1">
          <span className="w-2 h-2 rounded-full bg-primary animate-pulse" />
          Live
        </span>
      </div>
    </div>
  )
}
