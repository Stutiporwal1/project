"use client"

import { useState } from "react"
import {
  LayoutDashboard,
  Activity,
  Shield,
  Globe,
  History,
  Search,
  Network,
  Brain,
  Upload,
  Link,
  ChevronLeft,
  ChevronRight,
} from "lucide-react"
import { cn } from "@/lib/utils"

interface NavigationTabsProps {
  activeTab: string
  onTabChange: (tab: string) => void
}

const tabs = [
  { id: "analytics", label: "Analytics", icon: LayoutDashboard },
  { id: "threat-feed", label: "Threat Feed", icon: Activity },
  { id: "incident", label: "Incident Response", icon: Shield },
  { id: "threat-intel", label: "Threat Intel", icon: Globe },
  { id: "ip-verify", label: "IP Verification", icon: Search },
  { id: "historical", label: "Historical Analysis", icon: History },
  { id: "network", label: "Network", icon: Network },
  { id: "ai-predictions", label: "AI Predictions", icon: Brain },
  { id: "upload", label: "Static Upload", icon: Upload },
  { id: "api", label: "API Data", icon: Link },
]

export function NavigationTabs({ activeTab, onTabChange }: NavigationTabsProps) {
  const [scrollPosition, setScrollPosition] = useState(0)

  const scroll = (direction: "left" | "right") => {
    const container = document.getElementById("nav-tabs-container")
    if (container) {
      const scrollAmount = 200
      const newPosition =
        direction === "left" ? Math.max(0, scrollPosition - scrollAmount) : scrollPosition + scrollAmount
      container.scrollTo({ left: newPosition, behavior: "smooth" })
      setScrollPosition(newPosition)
    }
  }

  return (
    <div className="relative">
      {/* Scroll buttons */}
      <button
        onClick={() => scroll("left")}
        className="absolute left-0 top-1/2 -translate-y-1/2 z-10 p-1 rounded-full bg-background/80 backdrop-blur border border-border shadow-md hover:bg-muted transition-colors"
      >
        <ChevronLeft className="h-4 w-4" />
      </button>
      <button
        onClick={() => scroll("right")}
        className="absolute right-0 top-1/2 -translate-y-1/2 z-10 p-1 rounded-full bg-background/80 backdrop-blur border border-border shadow-md hover:bg-muted transition-colors"
      >
        <ChevronRight className="h-4 w-4" />
      </button>

      {/* Tabs container */}
      <div
        id="nav-tabs-container"
        className="overflow-x-auto scrollbar-hide mx-8 py-2"
        style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
      >
        <div className="flex items-center gap-1 min-w-max">
          {tabs.map((tab, idx) => (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className={cn(
                "flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-all duration-200",
                activeTab === tab.id
                  ? "bg-primary text-white shadow-md"
                  : "text-muted-foreground hover:bg-muted hover:text-foreground",
              )}
              style={{ animationDelay: `${idx * 0.03}s` }}
            >
              <tab.icon className="h-4 w-4" />
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Progress bar */}
      <div className="h-0.5 bg-muted rounded-full mt-1 mx-8">
        <div
          className="h-full bg-primary rounded-full transition-all duration-300"
          style={{ width: `${((tabs.findIndex((t) => t.id === activeTab) + 1) / tabs.length) * 100}%` }}
        />
      </div>
    </div>
  )
}
