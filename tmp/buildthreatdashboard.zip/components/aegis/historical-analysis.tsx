"use client"

import { useState, useEffect } from "react"
import { X, TrendingUp, Calendar, BarChart3, Lightbulb, ChevronDown } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
  Legend,
} from "recharts"

interface HistoricalAnalysisProps {
  isOpen: boolean
  onClose: () => void
}

const tabs = [
  { id: "timeline", label: "Timeline", icon: Calendar },
  { id: "trends", label: "Trends", icon: TrendingUp },
  { id: "distribution", label: "Distribution", icon: BarChart3 },
  { id: "insights", label: "Insights", icon: Lightbulb },
]

const timeRanges = ["Last 7 Days", "Last 30 Days", "Last 90 Days"]

const timelineData = [
  { date: "Jan 1", threats: 120, blocked: 180, critical: 25 },
  { date: "Jan 2", threats: 150, blocked: 200, critical: 32 },
  { date: "Jan 3", threats: 180, blocked: 220, critical: 28 },
  { date: "Jan 4", threats: 140, blocked: 190, critical: 35 },
  { date: "Jan 5", threats: 200, blocked: 250, critical: 42 },
  { date: "Jan 6", threats: 160, blocked: 210, critical: 30 },
  { date: "Jan 7", threats: 130, blocked: 175, critical: 22 },
]

const trendsData = [
  { name: "Week 1", ddos: 40, ransomware: 24, phishing: 35, malware: 28 },
  { name: "Week 2", ddos: 30, ransomware: 38, phishing: 45, malware: 32 },
  { name: "Week 3", ddos: 50, ransomware: 42, phishing: 30, malware: 25 },
  { name: "Week 4", ddos: 45, ransomware: 35, phishing: 55, malware: 40 },
]

const distributionData = {
  attackTypes: [
    { name: "DDoS", value: 35, color: "#6366f1" },
    { name: "Ransomware", value: 20, color: "#ef4444" },
    { name: "Phishing", value: 25, color: "#f97316" },
    { name: "Malware", value: 12, color: "#eab308" },
    { name: "XSS", value: 5, color: "#22c55e" },
    { name: "SQL Injection", value: 3, color: "#14b8a6" },
  ],
  severity: [
    { name: "Critical", value: 22, color: "#ef4444" },
    { name: "High", value: 35, color: "#f97316" },
    { name: "Medium", value: 28, color: "#eab308" },
    { name: "Low", value: 15, color: "#22c55e" },
  ],
}

const insightsData = [
  {
    type: "critical",
    title: "Critical Finding",
    description:
      "DDoS attacks have increased by 45% in the last 7 days. Recommend scaling infrastructure and implementing additional rate limiting.",
  },
  {
    type: "high",
    title: "High Priority",
    description:
      "Peak attack times correlate with business hours (2PM-6PM). Consider enhanced monitoring during these periods.",
  },
  {
    type: "trend",
    title: "Trend Analysis",
    description:
      "Phishing attempts targeting employee credentials show consistent pattern. Recommend additional security awareness training.",
  },
  {
    type: "positive",
    title: "Positive Development",
    description:
      "Automated blocking systems have successfully mitigated 89% of detected threats, reducing manual intervention required.",
  },
]

export function HistoricalAnalysis({ isOpen, onClose }: HistoricalAnalysisProps) {
  const [activeTab, setActiveTab] = useState("timeline")
  const [timeRange, setTimeRange] = useState("Last 7 Days")
  const [showTimeDropdown, setShowTimeDropdown] = useState(false)

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = "hidden"
    } else {
      document.body.style.overflow = "unset"
    }
    return () => {
      document.body.style.overflow = "unset"
    }
  }, [isOpen])

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={onClose} />

      {/* Modal */}
      <div className="relative w-full max-w-4xl max-h-[90vh] bg-card rounded-2xl shadow-2xl border border-border overflow-hidden animate-fade-in-up">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-border">
          <div className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-primary" />
            <h2 className="text-lg font-semibold">Historical Threat Analysis</h2>
          </div>
          <div className="flex items-center gap-3">
            {/* Time Range Selector */}
            <div className="relative">
              <button
                onClick={() => setShowTimeDropdown(!showTimeDropdown)}
                className="flex items-center gap-2 px-3 py-1.5 rounded-lg border border-border bg-background text-sm hover:bg-muted transition-colors"
              >
                {timeRange}
                <ChevronDown className="h-4 w-4" />
              </button>
              {showTimeDropdown && (
                <div className="absolute top-full right-0 mt-1 py-1 bg-card border border-border rounded-lg shadow-lg z-10">
                  {timeRanges.map((range) => (
                    <button
                      key={range}
                      onClick={() => {
                        setTimeRange(range)
                        setShowTimeDropdown(false)
                      }}
                      className="w-full px-4 py-2 text-sm text-left hover:bg-muted transition-colors"
                    >
                      {range}
                    </button>
                  ))}
                </div>
              )}
            </div>
            <Button variant="ghost" size="icon" onClick={onClose}>
              <X className="h-5 w-5" />
            </Button>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-border">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-6 py-3 text-sm font-medium transition-colors ${
                activeTab === tab.id
                  ? "text-primary border-b-2 border-primary bg-primary/5"
                  : "text-muted-foreground hover:text-foreground hover:bg-muted/50"
              }`}
            >
              <tab.icon className="h-4 w-4" />
              {tab.label}
            </button>
          ))}
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto max-h-[calc(90vh-140px)]">
          {activeTab === "timeline" && (
            <div className="space-y-4 animate-fade-in-up">
              <h3 className="font-medium flex items-center gap-2">
                <Calendar className="h-4 w-4" />
                Threat Activity Timeline
              </h3>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={timelineData}>
                    <defs>
                      <linearGradient id="colorThreats" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3} />
                        <stop offset="95%" stopColor="#6366f1" stopOpacity={0} />
                      </linearGradient>
                      <linearGradient id="colorBlocked" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#22c55e" stopOpacity={0.3} />
                        <stop offset="95%" stopColor="#22c55e" stopOpacity={0} />
                      </linearGradient>
                      <linearGradient id="colorCritical" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#ef4444" stopOpacity={0.3} />
                        <stop offset="95%" stopColor="#ef4444" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                    <XAxis dataKey="date" stroke="#94a3b8" fontSize={12} />
                    <YAxis stroke="#94a3b8" fontSize={12} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "#fff",
                        border: "1px solid #e2e8f0",
                        borderRadius: "8px",
                      }}
                    />
                    <Legend />
                    <Area
                      type="monotone"
                      dataKey="threats"
                      stroke="#6366f1"
                      fillOpacity={1}
                      fill="url(#colorThreats)"
                      name="Total Threats"
                    />
                    <Area
                      type="monotone"
                      dataKey="blocked"
                      stroke="#22c55e"
                      fillOpacity={1}
                      fill="url(#colorBlocked)"
                      name="Blocked"
                    />
                    <Area
                      type="monotone"
                      dataKey="critical"
                      stroke="#ef4444"
                      fillOpacity={1}
                      fill="url(#colorCritical)"
                      name="Critical"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>
          )}

          {activeTab === "trends" && (
            <div className="space-y-4 animate-fade-in-up">
              <h3 className="font-medium flex items-center gap-2">
                <TrendingUp className="h-4 w-4" />
                Attack Type Trends
              </h3>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={trendsData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                    <XAxis dataKey="name" stroke="#94a3b8" fontSize={12} />
                    <YAxis stroke="#94a3b8" fontSize={12} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "#fff",
                        border: "1px solid #e2e8f0",
                        borderRadius: "8px",
                      }}
                    />
                    <Legend />
                    <Line type="monotone" dataKey="ddos" stroke="#6366f1" strokeWidth={2} dot={{ r: 4 }} name="DDoS" />
                    <Line
                      type="monotone"
                      dataKey="ransomware"
                      stroke="#ef4444"
                      strokeWidth={2}
                      dot={{ r: 4 }}
                      name="Ransomware"
                    />
                    <Line
                      type="monotone"
                      dataKey="phishing"
                      stroke="#f97316"
                      strokeWidth={2}
                      dot={{ r: 4 }}
                      name="Phishing"
                    />
                    <Line
                      type="monotone"
                      dataKey="malware"
                      stroke="#eab308"
                      strokeWidth={2}
                      dot={{ r: 4 }}
                      name="Malware"
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
          )}

          {activeTab === "distribution" && (
            <div className="grid md:grid-cols-2 gap-6 animate-fade-in-up">
              <div>
                <h3 className="font-medium mb-4">Attack Types Distribution</h3>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={distributionData.attackTypes}
                        cx="50%"
                        cy="50%"
                        innerRadius={50}
                        outerRadius={80}
                        paddingAngle={2}
                        dataKey="value"
                        label={({ name, value }) => `${name} (${value}%)`}
                        labelLine={false}
                      >
                        {distributionData.attackTypes.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </div>
              <div>
                <h3 className="font-medium mb-4">Severity Distribution</h3>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={distributionData.severity} layout="vertical">
                      <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                      <XAxis type="number" stroke="#94a3b8" fontSize={12} />
                      <YAxis dataKey="name" type="category" stroke="#94a3b8" fontSize={12} width={70} />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: "#fff",
                          border: "1px solid #e2e8f0",
                          borderRadius: "8px",
                        }}
                      />
                      <Bar dataKey="value" radius={[0, 4, 4, 0]}>
                        {distributionData.severity.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>
          )}

          {activeTab === "insights" && (
            <div className="space-y-4 animate-fade-in-up">
              <h3 className="font-medium flex items-center gap-2">
                <Lightbulb className="h-4 w-4" />
                Key Insights & Recommendations
              </h3>
              <div className="space-y-3">
                {insightsData.map((insight, idx) => {
                  const colors = {
                    critical: "border-l-red-500 bg-red-50",
                    high: "border-l-orange-500 bg-orange-50",
                    trend: "border-l-primary bg-primary/5",
                    positive: "border-l-emerald-500 bg-emerald-50",
                  }
                  const titleColors = {
                    critical: "text-red-600",
                    high: "text-orange-600",
                    trend: "text-primary",
                    positive: "text-emerald-600",
                  }
                  return (
                    <div
                      key={idx}
                      className={`p-4 rounded-lg border-l-4 ${colors[insight.type as keyof typeof colors]} animate-fade-in-up`}
                      style={{ animationDelay: `${idx * 0.1}s` }}
                    >
                      <h4 className={`font-medium ${titleColors[insight.type as keyof typeof titleColors]}`}>
                        {insight.title}
                      </h4>
                      <p className="text-sm text-muted-foreground mt-1">{insight.description}</p>
                    </div>
                  )
                })}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
