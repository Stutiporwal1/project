"use client"

import { useEffect, useState } from "react"
import { generateNetworkData, type NetworkNode, type NetworkEdge } from "@/lib/threat-data"
import { Activity } from "lucide-react"

export function NetworkGraph() {
  const [data, setData] = useState<{ nodes: NetworkNode[]; edges: NetworkEdge[] }>({ nodes: [], edges: [] })
  const [activePacket, setActivePacket] = useState(0)

  useEffect(() => {
    setData(generateNetworkData())
  }, [])

  useEffect(() => {
    const interval = setInterval(() => {
      setActivePacket((prev) => (prev + 1) % 100)
    }, 50)
    return () => clearInterval(interval)
  }, [])

  const sources = data.nodes.filter((n) => n.type === "source")
  const relays = data.nodes.filter((n) => n.type === "relay")
  const targets = data.nodes.filter((n) => n.type === "target")

  const getColor = (severity?: string) => {
    switch (severity) {
      case "critical":
        return "#ef4444"
      case "high":
        return "#f97316"
      case "medium":
        return "#eab308"
      case "low":
        return "#22c55e"
      default:
        return "#6366f1"
    }
  }

  return (
    <div className="rounded-xl border border-border bg-card p-5 shadow-sm">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-lg bg-primary/10">
            <Activity className="h-4 w-4 text-primary" />
          </div>
          <span className="text-sm font-medium">Traffic Flow</span>
        </div>
        <div className="flex items-center gap-3 text-xs text-muted-foreground">
          <span className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-red-500" /> Threat
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-primary" /> Safe
          </span>
        </div>
      </div>

      <svg viewBox="0 0 400 200" className="w-full h-48">
        <defs>
          <linearGradient id="flowGradient" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#6366f1" stopOpacity="0.2" />
            <stop offset="50%" stopColor="#6366f1" stopOpacity="0.8" />
            <stop offset="100%" stopColor="#6366f1" stopOpacity="0.2" />
          </linearGradient>
          <filter id="glow">
            <feGaussianBlur stdDeviation="2" result="coloredBlur" />
            <feMerge>
              <feMergeNode in="coloredBlur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>

        {/* Connection lines with animated flow */}
        {data.edges.map((edge, i) => {
          const fromNode = data.nodes.find((n) => n.id === edge.from)
          const toNode = data.nodes.find((n) => n.id === edge.to)
          if (!fromNode || !toNode) return null

          const fromIdx =
            fromNode.type === "source"
              ? sources.indexOf(fromNode)
              : fromNode.type === "relay"
                ? relays.indexOf(fromNode)
                : targets.indexOf(fromNode)
          const toIdx =
            toNode.type === "source"
              ? sources.indexOf(toNode)
              : toNode.type === "relay"
                ? relays.indexOf(toNode)
                : targets.indexOf(toNode)

          const fromX = fromNode.type === "source" ? 50 : fromNode.type === "relay" ? 200 : 350
          const fromY =
            fromNode.type === "source"
              ? 40 + fromIdx * 50
              : fromNode.type === "relay"
                ? 50 + fromIdx * 40
                : 50 + toIdx * 50
          const toX = toNode.type === "source" ? 50 : toNode.type === "relay" ? 200 : 350
          const toY =
            toNode.type === "source" ? 40 + toIdx * 50 : toNode.type === "relay" ? 50 + toIdx * 40 : 50 + toIdx * 50

          const midX = (fromX + toX) / 2
          const curveOffset = (i % 2 === 0 ? 1 : -1) * 20

          return (
            <g key={edge.from + edge.to}>
              <path
                d={`M ${fromX} ${fromY} Q ${midX} ${fromY + curveOffset} ${toX} ${toY}`}
                fill="none"
                stroke={edge.active ? getColor(fromNode.severity) : "#e5e7eb"}
                strokeWidth={edge.active ? 2 : 1}
                strokeDasharray={edge.active ? "4 2" : "none"}
                className={edge.active ? "animate-data-flow" : ""}
              />
              {edge.active && (
                <circle r="3" fill={getColor(fromNode.severity)} filter="url(#glow)">
                  <animateMotion
                    dur="1.5s"
                    repeatCount="indefinite"
                    path={`M ${fromX} ${fromY} Q ${midX} ${fromY + curveOffset} ${toX} ${toY}`}
                  />
                </circle>
              )}
            </g>
          )
        })}

        {/* Source nodes */}
        {sources.map((node, i) => (
          <g key={node.id} className="cursor-pointer">
            <circle
              cx={50}
              cy={40 + i * 50}
              r={16}
              fill="white"
              stroke={getColor(node.severity)}
              strokeWidth={2}
              className="transition-all hover:scale-110"
              style={{ transformOrigin: `50px ${40 + i * 50}px` }}
            />
            <circle cx={50} cy={40 + i * 50} r={6} fill={getColor(node.severity)} className="animate-dot-pulse" />
            <text x={50} y={75 + i * 50} textAnchor="middle" className="text-[8px] fill-muted-foreground">
              {node.label.split(" ")[0]}
            </text>
          </g>
        ))}

        {/* Relay nodes */}
        {relays.map((node, i) => (
          <g key={node.id}>
            <rect
              x={188}
              y={38 + i * 40}
              width={24}
              height={24}
              rx={6}
              fill="white"
              stroke="#6366f1"
              strokeWidth={1.5}
            />
            <circle cx={200} cy={50 + i * 40} r={4} fill="#6366f1" />
          </g>
        ))}

        {/* Target nodes */}
        {targets.map((node, i) => (
          <g key={node.id}>
            <rect x={335} y={35 + i * 50} width={30} height={30} rx={8} fill="white" stroke="#10b981" strokeWidth={2} />
            <path d="M345 50 L350 55 L360 45" stroke="#10b981" strokeWidth={2} fill="none" strokeLinecap="round" />
            <text x={350} y={82 + i * 50} textAnchor="middle" className="text-[8px] fill-muted-foreground">
              Server {i + 1}
            </text>
          </g>
        ))}

        {/* Labels */}
        <text x={50} y={190} textAnchor="middle" className="text-[10px] fill-muted-foreground font-medium">
          Sources
        </text>
        <text x={200} y={190} textAnchor="middle" className="text-[10px] fill-muted-foreground font-medium">
          Firewall
        </text>
        <text x={350} y={190} textAnchor="middle" className="text-[10px] fill-muted-foreground font-medium">
          Protected
        </text>
      </svg>
    </div>
  )
}
