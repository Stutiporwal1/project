"use client"

import type React from "react"
import { useEffect, useState, useRef } from "react"
import { Globe, Clock, Zap, Activity, Shield } from "lucide-react"

interface AttackPath {
  id: string
  from: { lat: number; lng: number; country: string; city: string }
  to: { lat: number; lng: number; country: string; city: string }
  severity: "critical" | "high" | "medium" | "low"
  type: string
  sourceIP: string
  targetIP: string
  timestamp: string
  progress: number
}

const geoLocations = [
  { country: "Russia", city: "Moscow", lat: 55.7558, lng: 37.6173 },
  { country: "China", city: "Beijing", lat: 39.9042, lng: 116.4074 },
  { country: "USA", city: "Washington", lat: 38.9072, lng: -77.0369 },
  { country: "Germany", city: "Berlin", lat: 52.52, lng: 13.405 },
  { country: "Brazil", city: "São Paulo", lat: -23.5505, lng: -46.6333 },
  { country: "India", city: "New Delhi", lat: 28.6139, lng: 77.209 },
  { country: "UK", city: "London", lat: 51.5074, lng: -0.1278 },
  { country: "Japan", city: "Tokyo", lat: 35.6762, lng: 139.6503 },
  { country: "Australia", city: "Sydney", lat: -33.8688, lng: 151.2093 },
  { country: "South Africa", city: "Cape Town", lat: -33.9249, lng: 18.4241 },
  { country: "Iran", city: "Tehran", lat: 35.6892, lng: 51.389 },
  { country: "North Korea", city: "Pyongyang", lat: 39.0392, lng: 125.7625 },
  { country: "Ukraine", city: "Kyiv", lat: 50.4501, lng: 30.5234 },
  { country: "France", city: "Paris", lat: 48.8566, lng: 2.3522 },
  { country: "Canada", city: "Toronto", lat: 43.6532, lng: -79.3832 },
]

const severityColors = {
  critical: "#ef4444",
  high: "#f97316",
  medium: "#eab308",
  low: "#22c55e",
}

const attackTypes = [
  "DDoS Attack",
  "Ransomware",
  "Phishing Campaign",
  "SQL Injection",
  "Zero-Day Exploit",
  "Brute Force",
  "Man-in-the-Middle",
  "Cryptojacking",
]

function latLngToXY(lat: number, lng: number, width: number, height: number) {
  const x = ((lng + 180) / 360) * width
  const y = ((90 - lat) / 180) * height
  return { x, y }
}

function generateIP() {
  return Array.from({ length: 4 }, () => Math.floor(Math.random() * 256)).join(".")
}

const worldMapPath = `M 150,80 L 160,75 L 175,78 L 185,72 L 200,70 L 220,68 L 240,72 L 260,70 L 280,75 L 300,72 L 320,78 L 340,75 L 360,80 L 380,78 L 400,82 L 420,78 L 440,85 L 455,80 L 470,85 L 485,82 L 500,88 L 515,85 L 530,90 L 545,88 L 560,92 L 575,90 L 590,95 L 600,92 
M 120,120 L 130,115 L 145,118 L 155,112 L 170,115 L 185,110 L 200,115 L 215,112 L 230,118 L 245,115 L 260,120 L 275,118 L 290,122 L 305,120 L 320,125 L 335,122 L 350,128 L 365,125 L 380,130 L 395,128 L 410,132 L 425,130 L 440,135 L 455,132 L 470,138 L 485,135 L 500,140 L 510,138
M 100,160 L 120,155 L 145,158 L 165,152 L 190,155 L 210,150 L 235,155 L 255,152 L 280,158 L 300,155 L 325,160 L 345,158 L 370,162 L 390,160 L 415,165 L 435,162 L 460,168 L 480,165 L 505,170 L 525,168 L 550,172 L 570,170 L 595,175 L 615,172 L 640,178 L 660,175
M 200,200 L 210,195 L 230,198 L 250,192 L 270,195 L 290,190 L 310,195 L 330,192 L 350,198 L 370,195 L 390,200 L 410,198 L 430,202 L 450,200 L 470,205 L 490,202 L 510,208 L 530,205 L 550,210 L 565,208
M 440,240 L 455,235 L 475,238 L 495,232 L 515,235 L 535,230 L 555,235 L 570,232 L 590,238 L 605,235 L 620,240 L 635,238 L 650,242 L 665,240 L 680,245 L 695,242
M 520,280 L 540,275 L 560,278 L 580,272 L 600,275 L 615,270`

// Continent outlines for better map visualization
const continents = {
  northAmerica:
    "M 80,90 Q 100,85 130,92 L 160,88 Q 190,95 200,110 L 180,130 Q 160,145 140,150 L 110,145 Q 85,135 80,115 Z",
  southAmerica:
    "M 150,195 Q 165,190 175,200 L 185,230 Q 190,260 180,285 L 165,300 Q 150,295 145,275 L 140,245 Q 142,220 150,195 Z",
  europe:
    "M 290,85 Q 320,80 350,88 L 370,95 Q 390,105 385,120 L 365,130 Q 340,135 315,128 L 295,115 Q 280,100 290,85 Z",
  africa:
    "M 295,145 Q 320,140 345,150 L 365,175 Q 375,210 365,245 L 345,270 Q 315,280 295,265 L 280,230 Q 275,190 295,145 Z",
  asia: "M 390,70 Q 450,60 520,75 L 580,90 Q 620,110 610,140 L 580,165 Q 530,180 470,170 L 420,150 Q 380,125 390,70 Z",
  australia: "M 545,235 Q 580,225 615,240 L 635,260 Q 640,285 620,300 L 580,305 Q 550,295 545,270 L 545,235 Z",
}

export function WorldMap() {
  const [attacks, setAttacks] = useState<AttackPath[]>([])
  const [hoveredAttack, setHoveredAttack] = useState<AttackPath | null>(null)
  const [tooltipPosition, setTooltipPosition] = useState({ x: 0, y: 0 })
  const [totalBlocked, setTotalBlocked] = useState(2847)
  const containerRef = useRef<HTMLDivElement>(null)
  const width = 720
  const height = 360

  useEffect(() => {
    const generateAttack = (): AttackPath => {
      const from = geoLocations[Math.floor(Math.random() * geoLocations.length)]
      let to = geoLocations[Math.floor(Math.random() * geoLocations.length)]
      while (to.country === from.country) {
        to = geoLocations[Math.floor(Math.random() * geoLocations.length)]
      }
      const severities: ("critical" | "high" | "medium" | "low")[] = ["critical", "high", "medium", "low"]
      const weights = [0.15, 0.25, 0.35, 0.25]
      const rand = Math.random()
      let cumulative = 0
      let severity: "critical" | "high" | "medium" | "low" = "medium"
      for (let i = 0; i < weights.length; i++) {
        cumulative += weights[i]
        if (rand < cumulative) {
          severity = severities[i]
          break
        }
      }

      return {
        id: Math.random().toString(36).slice(2, 8),
        from: { ...from },
        to: { ...to },
        severity,
        type: attackTypes[Math.floor(Math.random() * attackTypes.length)],
        sourceIP: generateIP(),
        targetIP: generateIP(),
        timestamp: new Date().toLocaleTimeString(),
        progress: 0,
      }
    }

    setAttacks([generateAttack(), generateAttack(), generateAttack(), generateAttack()])

    const addInterval = setInterval(() => {
      setAttacks((prev) => {
        if (prev.length < 8) {
          return [...prev, generateAttack()]
        }
        return prev
      })
      setTotalBlocked((prev) => prev + Math.floor(Math.random() * 3) + 1)
    }, 2500)

    const animateInterval = setInterval(() => {
      setAttacks((prev) => prev.map((a) => ({ ...a, progress: a.progress + 1.5 })).filter((a) => a.progress <= 100))
    }, 40)

    return () => {
      clearInterval(addInterval)
      clearInterval(animateInterval)
    }
  }, [])

  const createArcPath = (from: { x: number; y: number }, to: { x: number; y: number }) => {
    const dx = to.x - from.x
    const dy = to.y - from.y
    const dist = Math.sqrt(dx * dx + dy * dy)
    const midX = (from.x + to.x) / 2
    const midY = (from.y + to.y) / 2 - dist * 0.25
    return `M ${from.x} ${from.y} Q ${midX} ${midY} ${to.x} ${to.y}`
  }

  const getPointOnArc = (from: { x: number; y: number }, to: { x: number; y: number }, progress: number) => {
    const t = progress / 100
    const dx = to.x - from.x
    const dy = to.y - from.y
    const dist = Math.sqrt(dx * dx + dy * dy)
    const midX = (from.x + to.x) / 2
    const midY = (from.y + to.y) / 2 - dist * 0.25
    const x = (1 - t) * (1 - t) * from.x + 2 * (1 - t) * t * midX + t * t * to.x
    const y = (1 - t) * (1 - t) * from.y + 2 * (1 - t) * t * midY + t * t * to.y
    return { x, y }
  }

  const handleMouseMove = (e: React.MouseEvent, attack: AttackPath) => {
    if (containerRef.current) {
      const rect = containerRef.current.getBoundingClientRect()
      setTooltipPosition({
        x: e.clientX - rect.left,
        y: e.clientY - rect.top,
      })
    }
    setHoveredAttack(attack)
  }

  const criticalCount = attacks.filter((a) => a.severity === "critical").length
  const highCount = attacks.filter((a) => a.severity === "high").length

  return (
    <div className="rounded-xl border border-border bg-card overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-5 py-4 border-b border-border bg-muted/30">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-primary/10">
            <Globe className="h-5 w-5 text-primary" />
          </div>
          <div>
            <h3 className="font-semibold text-foreground">Global Threat Map</h3>
            <p className="text-xs text-muted-foreground">Real-time attack visualization</p>
          </div>
        </div>
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2">
            <Activity className="h-4 w-4 text-red-500 animate-pulse" />
            <span className="text-sm font-medium">{attacks.length} Active</span>
          </div>
          <div className="flex items-center gap-2">
            <Shield className="h-4 w-4 text-emerald-500" />
            <span className="text-sm font-medium">{totalBlocked.toLocaleString()} Blocked</span>
          </div>
        </div>
      </div>

      {/* Map */}
      <div ref={containerRef} className="relative bg-slate-950">
        <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-auto">
          <defs>
            {/* Gradient for ocean */}
            <linearGradient id="oceanGradient" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#0f172a" />
              <stop offset="100%" stopColor="#1e293b" />
            </linearGradient>
            {/* Glow filters for attacks */}
            <filter id="glow-critical" x="-50%" y="-50%" width="200%" height="200%">
              <feGaussianBlur stdDeviation="3" result="blur" />
              <feMerge>
                <feMergeNode in="blur" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>
            <filter id="glow-high" x="-50%" y="-50%" width="200%" height="200%">
              <feGaussianBlur stdDeviation="2.5" result="blur" />
              <feMerge>
                <feMergeNode in="blur" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>
            {/* Animated dash pattern */}
            <pattern id="grid" width="30" height="30" patternUnits="userSpaceOnUse">
              <path d="M 30 0 L 0 0 0 30" fill="none" stroke="rgba(100, 116, 139, 0.1)" strokeWidth="0.5" />
            </pattern>
          </defs>

          {/* Ocean background */}
          <rect width={width} height={height} fill="url(#oceanGradient)" />
          <rect width={width} height={height} fill="url(#grid)" />

          {/* Continent shapes */}
          {Object.entries(continents).map(([name, path]) => (
            <path key={name} d={path} fill="rgba(51, 65, 85, 0.6)" stroke="rgba(100, 116, 139, 0.4)" strokeWidth="1" />
          ))}

          {/* World map outline overlay */}
          <path d={worldMapPath} fill="none" stroke="rgba(100, 116, 139, 0.3)" strokeWidth="0.5" />

          {/* Location markers with labels */}
          {geoLocations.map((loc) => {
            const { x, y } = latLngToXY(loc.lat, loc.lng, width, height)
            const isAttackSource = attacks.some((a) => a.from.country === loc.country)
            const isAttackTarget = attacks.some((a) => a.to.country === loc.country)
            return (
              <g key={loc.country}>
                {/* Outer glow for active locations */}
                {(isAttackSource || isAttackTarget) && (
                  <circle
                    cx={x}
                    cy={y}
                    r={12}
                    fill={isAttackSource ? "rgba(239, 68, 68, 0.15)" : "rgba(34, 197, 94, 0.15)"}
                  >
                    <animate attributeName="r" values="8;14;8" dur="2s" repeatCount="indefinite" />
                    <animate attributeName="opacity" values="0.3;0.1;0.3" dur="2s" repeatCount="indefinite" />
                  </circle>
                )}
                {/* Location dot */}
                <circle
                  cx={x}
                  cy={y}
                  r={isAttackSource || isAttackTarget ? 4 : 3}
                  fill={isAttackSource ? "#ef4444" : isAttackTarget ? "#22c55e" : "#64748b"}
                  stroke={isAttackSource || isAttackTarget ? "#fff" : "transparent"}
                  strokeWidth="1"
                />
                {/* City label for active locations */}
                {(isAttackSource || isAttackTarget) && (
                  <text
                    x={x}
                    y={y - 10}
                    textAnchor="middle"
                    fill="rgba(255,255,255,0.7)"
                    fontSize="8"
                    fontFamily="system-ui"
                  >
                    {loc.city}
                  </text>
                )}
              </g>
            )
          })}

          {/* Attack paths */}
          {attacks.map((attack) => {
            const from = latLngToXY(attack.from.lat, attack.from.lng, width, height)
            const to = latLngToXY(attack.to.lat, attack.to.lng, width, height)
            const path = createArcPath(from, to)
            const color = severityColors[attack.severity]
            const isHovered = hoveredAttack?.id === attack.id
            const currentPoint = getPointOnArc(from, to, attack.progress)
            const glowFilter =
              attack.severity === "critical"
                ? "url(#glow-critical)"
                : attack.severity === "high"
                  ? "url(#glow-high)"
                  : ""

            return (
              <g
                key={attack.id}
                onMouseMove={(e) => handleMouseMove(e as unknown as React.MouseEvent, attack)}
                onMouseLeave={() => setHoveredAttack(null)}
                className="cursor-pointer"
              >
                {/* Base trail */}
                <path
                  d={path}
                  fill="none"
                  stroke={color}
                  strokeWidth={isHovered ? 2 : 1}
                  strokeDasharray="6 4"
                  opacity={0.3}
                />
                {/* Animated progress path */}
                <path
                  d={path}
                  fill="none"
                  stroke={color}
                  strokeWidth={isHovered ? 3 : 2}
                  strokeLinecap="round"
                  strokeDasharray={`${attack.progress * 4} 1000`}
                  filter={glowFilter}
                />
                {/* Moving projectile */}
                <circle
                  cx={currentPoint.x}
                  cy={currentPoint.y}
                  r={isHovered ? 6 : 5}
                  fill={color}
                  filter={glowFilter}
                />
                <circle cx={currentPoint.x} cy={currentPoint.y} r={isHovered ? 3 : 2} fill="#fff" />
                {/* Source pulse */}
                <circle cx={from.x} cy={from.y} r={8} fill={color} opacity={0}>
                  <animate attributeName="r" values="4;16;4" dur="1.5s" repeatCount="indefinite" />
                  <animate attributeName="opacity" values="0.6;0;0.6" dur="1.5s" repeatCount="indefinite" />
                </circle>
                {/* Invisible hitbox */}
                <path d={path} fill="none" stroke="transparent" strokeWidth={20} />
              </g>
            )
          })}
        </svg>

        {/* Tooltip */}
        {hoveredAttack && (
          <div
            className="absolute z-20 pointer-events-none animate-in fade-in-0 zoom-in-95 duration-150"
            style={{
              left: tooltipPosition.x + 15,
              top: tooltipPosition.y - 10,
              transform: tooltipPosition.x > 450 ? "translateX(-110%)" : "none",
            }}
          >
            <div className="bg-slate-900/95 backdrop-blur-sm border border-slate-700 rounded-lg shadow-2xl p-4 min-w-[240px]">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <Zap className="h-4 w-4" style={{ color: severityColors[hoveredAttack.severity] }} />
                  <span className="font-semibold text-white">{hoveredAttack.type}</span>
                </div>
                <span
                  className="text-xs px-2 py-1 rounded-full capitalize font-medium"
                  style={{
                    backgroundColor: `${severityColors[hoveredAttack.severity]}25`,
                    color: severityColors[hoveredAttack.severity],
                  }}
                >
                  {hoveredAttack.severity}
                </span>
              </div>
              <div className="space-y-2 text-sm">
                <div className="flex items-center justify-between py-1.5 px-2 bg-red-500/10 rounded">
                  <span className="text-slate-400">Source</span>
                  <div className="text-right">
                    <p className="font-mono text-red-400 text-xs">{hoveredAttack.sourceIP}</p>
                    <p className="text-white text-xs">
                      {hoveredAttack.from.city}, {hoveredAttack.from.country}
                    </p>
                  </div>
                </div>
                <div className="flex items-center justify-between py-1.5 px-2 bg-emerald-500/10 rounded">
                  <span className="text-slate-400">Target</span>
                  <div className="text-right">
                    <p className="font-mono text-emerald-400 text-xs">{hoveredAttack.targetIP}</p>
                    <p className="text-white text-xs">
                      {hoveredAttack.to.city}, {hoveredAttack.to.country}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-1.5 text-xs text-slate-400 pt-1">
                  <Clock className="h-3 w-3" />
                  <span>{hoveredAttack.timestamp}</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Map overlay stats */}
        <div className="absolute bottom-4 left-4 flex items-center gap-3">
          {criticalCount > 0 && (
            <div className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-full bg-red-500/20 border border-red-500/30 text-red-400 text-xs font-medium">
              <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
              {criticalCount} Critical
            </div>
          )}
          {highCount > 0 && (
            <div className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-full bg-orange-500/20 border border-orange-500/30 text-orange-400 text-xs font-medium">
              <span className="w-2 h-2 rounded-full bg-orange-500" />
              {highCount} High
            </div>
          )}
        </div>
      </div>

      {/* Legend footer */}
      <div className="flex items-center justify-between px-5 py-3 border-t border-border bg-muted/30">
        <div className="flex items-center gap-5 text-xs">
          {Object.entries(severityColors).map(([sev, color]) => (
            <div key={sev} className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: color }} />
              <span className="capitalize text-muted-foreground">{sev}</span>
            </div>
          ))}
        </div>
        <span className="text-xs text-muted-foreground">Updated in real-time</span>
      </div>
    </div>
  )
}
