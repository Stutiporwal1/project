"use client"

import { killChainStages } from "@/lib/threat-data"
import { Shield, CheckCircle2, AlertCircle, Circle, ArrowRight } from "lucide-react"

function StageIcon({ status }: { status: "complete" | "active" | "pending" }) {
  if (status === "complete")
    return (
      <div className="p-1.5 rounded-full bg-emerald-100">
        <CheckCircle2 className="h-4 w-4 text-emerald-600" />
      </div>
    )
  if (status === "active")
    return (
      <div className="p-1.5 rounded-full bg-orange-100 animate-pulse">
        <AlertCircle className="h-4 w-4 text-orange-600" />
      </div>
    )
  return (
    <div className="p-1.5 rounded-full bg-gray-100">
      <Circle className="h-4 w-4 text-gray-400" />
    </div>
  )
}

export function KillChain() {
  const activeIndex = killChainStages.findIndex((s) => s.status === "active")
  const blockedPercentage = Math.round(((activeIndex + 1) / killChainStages.length) * 100)

  return (
    <div className="rounded-xl border border-border bg-card p-5 shadow-sm">
      <div className="flex items-center justify-between mb-5">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-lg bg-primary/10">
            <Shield className="h-4 w-4 text-primary" />
          </div>
          <span className="text-sm font-medium">Attack Chain</span>
        </div>
        <div className="px-3 py-1 rounded-full bg-emerald-100 text-emerald-700 text-xs font-medium">
          {blockedPercentage}% blocked
        </div>
      </div>

      {/* Visual progress */}
      <div className="flex items-center gap-1 mb-5">
        {killChainStages.map((stage, i) => (
          <div key={stage.id} className="flex-1 flex items-center">
            <div
              className={`
                h-2 flex-1 rounded-full transition-all duration-500
                ${stage.status === "complete" ? "bg-emerald-500" : ""}
                ${stage.status === "active" ? "bg-orange-500 animate-pulse" : ""}
                ${stage.status === "pending" ? "bg-gray-200" : ""}
              `}
            />
            {i < killChainStages.length - 1 && (
              <ArrowRight className="h-3 w-3 text-muted-foreground mx-1 flex-shrink-0" />
            )}
          </div>
        ))}
      </div>

      {/* Stages list */}
      <div className="space-y-2">
        {killChainStages.map((stage, i) => (
          <div
            key={stage.id}
            className={`
              flex items-center gap-3 p-3 rounded-lg transition-all duration-300
              ${stage.status === "active" ? "bg-orange-50 border border-orange-200" : ""}
              ${stage.status === "complete" ? "bg-emerald-50/50" : ""}
              ${stage.status === "pending" ? "opacity-50" : ""}
              animate-fade-in-up
            `}
            style={{ animationDelay: `${i * 0.05}s` }}
          >
            <span className="text-xs font-mono text-muted-foreground w-5">{String(i + 1).padStart(2, "0")}</span>
            <StageIcon status={stage.status} />
            <span className="text-sm flex-1">{stage.name}</span>
            {stage.threats > 0 && (
              <span
                className={`
                text-xs font-mono px-2 py-0.5 rounded-full
                ${stage.status === "active" ? "bg-orange-200 text-orange-800" : "bg-gray-100 text-gray-600"}
              `}
              >
                {stage.threats}
              </span>
            )}
          </div>
        ))}
      </div>
    </div>
  )
}
