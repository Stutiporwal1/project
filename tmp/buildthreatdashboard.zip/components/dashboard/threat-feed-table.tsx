"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search } from "lucide-react"
import type { ThreatEvent, SeverityLevel } from "@/lib/threat-data"
import { cn } from "@/lib/utils"

interface ThreatFeedTableProps {
  threats: ThreatEvent[]
  fullWidth?: boolean
}

const severityColors: Record<SeverityLevel, string> = {
  Critical: "text-red-500",
  High: "text-pink-500",
  Medium: "text-orange-500",
  Low: "text-green-500",
}

export function ThreatFeedTable({ threats, fullWidth }: ThreatFeedTableProps) {
  const [search, setSearch] = useState("")
  const [severityFilter, setSeverityFilter] = useState<string>("all")

  const filteredThreats = threats.filter((threat) => {
    const matchesSearch =
      threat.type.toLowerCase().includes(search.toLowerCase()) ||
      threat.sourceIp.includes(search) ||
      threat.targetIp.includes(search) ||
      threat.country.toLowerCase().includes(search.toLowerCase())

    const matchesSeverity = severityFilter === "all" || threat.severity === severityFilter

    return matchesSearch && matchesSeverity
  })

  return (
    <Card className={cn("bg-card/50 border-border/50", fullWidth ? "col-span-full" : "")}>
      <CardHeader className="pb-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <CardTitle className="text-cyan-400 text-lg">Live Threat Feed</CardTitle>
          <div className="flex items-center gap-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search threats..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-9 bg-secondary/50 border-border/50 w-48"
              />
            </div>
            <Select value={severityFilter} onValueChange={setSeverityFilter}>
              <SelectTrigger className="w-36 bg-secondary/50 border-border/50">
                <SelectValue placeholder="All Severities" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Severities</SelectItem>
                <SelectItem value="Critical">Critical</SelectItem>
                <SelectItem value="High">High</SelectItem>
                <SelectItem value="Medium">Medium</SelectItem>
                <SelectItem value="Low">Low</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border/50 text-left">
                <th className="pb-3 text-muted-foreground font-medium text-sm">Time</th>
                <th className="pb-3 text-muted-foreground font-medium text-sm">Type</th>
                <th className="pb-3 text-muted-foreground font-medium text-sm">Source</th>
                <th className="pb-3 text-muted-foreground font-medium text-sm">Target</th>
                <th className="pb-3 text-muted-foreground font-medium text-sm">Severity</th>
                <th className="pb-3 text-muted-foreground font-medium text-sm">Status</th>
                <th className="pb-3 text-muted-foreground font-medium text-sm">Country</th>
              </tr>
            </thead>
            <tbody>
              {filteredThreats.slice(0, 15).map((threat) => (
                <tr key={threat.id} className="border-b border-border/30 hover:bg-secondary/30 transition-colors">
                  <td className="py-3 text-sm text-muted-foreground font-mono">
                    {threat.timestamp.toLocaleTimeString()}
                  </td>
                  <td className="py-3">
                    <Badge variant="outline" className="bg-secondary/50 text-foreground border-border/50">
                      {threat.type}
                    </Badge>
                  </td>
                  <td className="py-3 text-sm font-mono text-muted-foreground">{threat.sourceIp}</td>
                  <td className="py-3 text-sm font-mono text-muted-foreground">{threat.targetIp}</td>
                  <td className={cn("py-3 text-sm font-medium", severityColors[threat.severity])}>{threat.severity}</td>
                  <td className="py-3">
                    <Badge className="bg-cyan-500/20 text-cyan-400 border-cyan-500/50">{threat.status}</Badge>
                  </td>
                  <td className="py-3 text-sm text-muted-foreground">{threat.country}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  )
}
