"use client"
import {
  BarChart3,
  AlertTriangle,
  ShieldCheck,
  Globe2,
  Search,
  TrendingUp,
  Wifi,
  Brain,
  Upload,
  Link,
} from "lucide-react"
import { cn } from "@/lib/utils"

const tabs = [
  { id: "analytics", label: "Analytics", icon: BarChart3 },
  { id: "threat-feed", label: "Threat Feed", icon: AlertTriangle },
  { id: "incident-response", label: "Incident Response", icon: ShieldCheck },
  { id: "threat-intel", label: "Threat Intel", icon: Globe2 },
  { id: "ip-verification", label: "IP Verification", icon: Search },
  { id: "historical-analysis", label: "Historical Analysis", icon: TrendingUp },
  { id: "network", label: "Network", icon: Wifi },
  { id: "ai-predictions", label: "AI Predictions", icon: Brain },
  { id: "static-upload", label: "Static Upload", icon: Upload },
  { id: "api-data", label: "API Data", icon: Link },
]

interface NavigationTabsProps {
  activeTab: string
  onTabChange: (tab: string) => void
}

export function NavigationTabs({ activeTab, onTabChange }: NavigationTabsProps) {
  return (
    <div className="relative">
      <div className="flex overflow-x-auto gap-1 pb-2 scrollbar-thin">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => onTabChange(tab.id)}
            className={cn(
              "flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-all",
              activeTab === tab.id
                ? "bg-cyan-500/20 text-cyan-400 border border-cyan-500/50"
                : "text-muted-foreground hover:bg-secondary/50 hover:text-foreground",
            )}
          >
            <tab.icon className="h-4 w-4" />
            {tab.label}
          </button>
        ))}
      </div>
      {/* Progress bar */}
      <div className="h-1 bg-secondary rounded-full mt-2">
        <div
          className="h-full bg-gradient-to-r from-cyan-500 to-green-500 rounded-full transition-all duration-300"
          style={{ width: `${((tabs.findIndex((t) => t.id === activeTab) + 1) / tabs.length) * 100}%` }}
        />
      </div>
    </div>
  )
}
