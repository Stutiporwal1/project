"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Brain, Check } from "lucide-react"
import { aiModels } from "@/lib/threat-data"
import { cn } from "@/lib/utils"

export function AiModelSelector() {
  const [selectedModel, setSelectedModel] = useState(aiModels[0].name)

  return (
    <Card className="bg-card/50 border-border/50">
      <CardHeader>
        <CardTitle className="text-cyan-400 flex items-center gap-2">
          <Brain className="h-5 w-5" />
          Select AI/ML Model
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {aiModels.map((model) => (
            <div
              key={model.name}
              onClick={() => setSelectedModel(model.name)}
              className={cn(
                "p-4 rounded-lg border cursor-pointer transition-all",
                selectedModel === model.name
                  ? "border-cyan-500 bg-cyan-500/10"
                  : "border-border/50 bg-secondary/20 hover:border-border",
              )}
            >
              <div className="flex items-start justify-between mb-2">
                <div>
                  <h3 className="font-semibold text-foreground">{model.name}</h3>
                  <p className="text-xs text-muted-foreground">{model.type}</p>
                </div>
                {selectedModel === model.name && (
                  <div className="bg-cyan-500 rounded-full p-1">
                    <Check className="h-3 w-3 text-white" />
                  </div>
                )}
              </div>

              <div className="flex items-center gap-3 mt-4">
                <span className="text-sm text-muted-foreground">{model.accuracy}% Accuracy</span>
                <Badge variant="outline" className="bg-cyan-500/20 text-cyan-400 border-cyan-500/50">
                  {model.latency}ms
                </Badge>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
