"use client"

import { AlertTriangle, Shield, AlertCircle, Globe } from "lucide-react"
import { Card } from "@/components/ui/card"

interface StatsCardsProps {
  activeThreats: number
  blocked: number
  criticalAlerts: number
  totalScanned: number
}

export function StatsCards({ activeThreats, blocked, criticalAlerts, totalScanned }: StatsCardsProps) {
  const stats = [
    {
      label: "Active Threats",
      value: activeThreats,
      icon: AlertTriangle,
      color: "text-red-500",
      bgColor: "bg-red-500/10",
    },
    {
      label: "Blocked",
      value: blocked,
      icon: Shield,
      color: "text-green-500",
      bgColor: "bg-green-500/10",
    },
    {
      label: "Critical Alerts",
      value: criticalAlerts,
      icon: AlertCircle,
      color: "text-yellow-500",
      bgColor: "bg-yellow-500/10",
    },
    {
      label: "Total Scanned",
      value: totalScanned,
      icon: Globe,
      color: "text-cyan-400",
      bgColor: "bg-cyan-500/10",
    },
  ]

  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
      {stats.map((stat) => (
        <Card key={stat.label} className="bg-card/50 border-border/50 p-4 flex items-center justify-between">
          <div>
            <p className="text-muted-foreground text-sm">{stat.label}</p>
            <p className={`text-3xl font-bold ${stat.color}`}>{stat.value}</p>
          </div>
          <div className={`${stat.bgColor} p-3 rounded-lg`}>
            <stat.icon className={`h-6 w-6 ${stat.color}`} />
          </div>
        </Card>
      ))}
    </div>
  )
}
