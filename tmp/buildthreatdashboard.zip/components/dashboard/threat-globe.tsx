"use client"

import { useState, useEffect, useRef } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Globe, ArrowRight } from "lucide-react"
import type { ThreatEvent, SeverityLevel } from "@/lib/threat-data"
import { cn } from "@/lib/utils"

interface ThreatGlobeProps {
  threats: ThreatEvent[]
}

const severityColors: Record<SeverityLevel, string> = {
  Critical: "#ef4444",
  High: "#ec4899",
  Medium: "#f97316",
  Low: "#22c55e",
}

const severityTextColors: Record<SeverityLevel, string> = {
  Critical: "text-red-500",
  High: "text-pink-500",
  Medium: "text-orange-500",
  Low: "text-green-500",
}

export function ThreatGlobe({ threats }: ThreatGlobeProps) {
  const [isStatic, setIsStatic] = useState(false)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [activeThreats, setActiveThreats] = useState(threats.slice(0, 5))

  useEffect(() => {
    setActiveThreats(threats.slice(0, 5))
  }, [threats])

  // Draw globe visualization
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const width = canvas.width
    const height = canvas.height
    const centerX = width / 2
    const centerY = height / 2
    const radius = Math.min(width, height) / 2 - 40

    let animationFrame: number
    let rotation = 0

    const draw = () => {
      ctx.clearRect(0, 0, width, height)

      // Draw globe background
      ctx.beginPath()
      ctx.arc(centerX, centerY, radius, 0, Math.PI * 2)
      ctx.fillStyle = "rgba(6, 182, 212, 0.05)"
      ctx.fill()
      ctx.strokeStyle = "rgba(6, 182, 212, 0.3)"
      ctx.lineWidth = 2
      ctx.stroke()

      // Draw latitude lines
      for (let i = 1; i < 5; i++) {
        ctx.beginPath()
        ctx.ellipse(centerX, centerY, radius * (i / 5), radius * (i / 5) * 0.3, 0, 0, Math.PI * 2)
        ctx.strokeStyle = "rgba(6, 182, 212, 0.15)"
        ctx.lineWidth = 1
        ctx.stroke()
      }

      // Draw longitude lines
      for (let i = 0; i < 8; i++) {
        const angle = (i / 8) * Math.PI + rotation
        ctx.beginPath()
        ctx.moveTo(centerX + Math.cos(angle) * radius, centerY - radius * 0.8)
        ctx.quadraticCurveTo(
          centerX + Math.cos(angle) * radius * 1.2,
          centerY,
          centerX + Math.cos(angle) * radius,
          centerY + radius * 0.8,
        )
        ctx.strokeStyle = "rgba(6, 182, 212, 0.15)"
        ctx.stroke()
      }

      // Draw threat points
      threats.slice(0, 30).forEach((threat, index) => {
        const angle = (threat.coordinates.lng / 180) * Math.PI + rotation
        const latRatio = threat.coordinates.lat / 90
        const x = centerX + Math.cos(angle) * radius * 0.8 * Math.cos((latRatio * Math.PI) / 2)
        const y = centerY + latRatio * radius * 0.6

        const pulseScale = 1 + Math.sin(Date.now() / 500 + index) * 0.3
        const baseRadius = 6 * pulseScale

        ctx.beginPath()
        ctx.arc(x, y, baseRadius, 0, Math.PI * 2)
        ctx.fillStyle = severityColors[threat.severity]
        ctx.globalAlpha = 0.8
        ctx.fill()

        // Glow effect
        ctx.beginPath()
        ctx.arc(x, y, baseRadius * 2, 0, Math.PI * 2)
        ctx.fillStyle = severityColors[threat.severity]
        ctx.globalAlpha = 0.2
        ctx.fill()
        ctx.globalAlpha = 1
      })

      // Country labels
      const labels = [
        { name: "Ukraine", x: 0.6, y: -0.3 },
        { name: "France", x: 0.1, y: -0.2 },
        { name: "Egypt", x: 0.3, y: 0.1 },
        { name: "Brazil", x: -0.4, y: 0.4 },
        { name: "South Africa", x: 0.2, y: 0.5 },
      ]

      ctx.font = "12px Geist"
      ctx.fillStyle = "rgba(255, 255, 255, 0.6)"
      labels.forEach((label) => {
        ctx.fillText(label.name, centerX + label.x * radius, centerY + label.y * radius)
      })

      if (!isStatic) {
        rotation += 0.002
        animationFrame = requestAnimationFrame(draw)
      }
    }

    draw()

    return () => {
      if (animationFrame) cancelAnimationFrame(animationFrame)
    }
  }, [threats, isStatic])

  return (
    <Card className="bg-card/50 border-border/50">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Globe className="h-5 w-5 text-cyan-400" />
            <CardTitle className="text-lg">3D Threat Globe - Live Attack Feed</CardTitle>
          </div>
          <Button variant="outline" size="sm" onClick={() => setIsStatic(!isStatic)} className="text-xs">
            {isStatic ? "Animate" : "Static View"}
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-4">
          {/* Globe Canvas */}
          <div className="lg:col-span-3 relative">
            <canvas ref={canvasRef} width={400} height={350} className="w-full h-auto" />
            {/* Legend */}
            <div className="flex items-center gap-4 mt-2 text-xs">
              {Object.entries(severityColors).map(([severity, color]) => (
                <div key={severity} className="flex items-center gap-1">
                  <div className="w-2 h-2 rounded-full" style={{ backgroundColor: color }} />
                  <span className="text-muted-foreground">{severity}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Active Attacks Panel */}
          <div className="lg:col-span-2 space-y-3">
            <div className="flex items-center gap-2">
              <Badge className="bg-red-500 text-white animate-pulse">LIVE</Badge>
              <span className="text-sm font-medium">Active Attacks</span>
            </div>

            <div className="space-y-3 max-h-[280px] overflow-y-auto pr-2">
              {activeThreats.map((threat) => (
                <div
                  key={threat.id}
                  className={cn(
                    "p-3 rounded-lg border",
                    threat.severity === "Critical"
                      ? "bg-red-500/10 border-red-500/30"
                      : threat.severity === "High"
                        ? "bg-pink-500/10 border-pink-500/30"
                        : threat.severity === "Medium"
                          ? "bg-orange-500/10 border-orange-500/30"
                          : "bg-green-500/10 border-green-500/30",
                  )}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className={cn("text-sm font-medium", severityTextColors[threat.severity])}>
                      {threat.severity}
                    </span>
                    <span className="text-xs text-muted-foreground">{threat.timestamp.toLocaleTimeString()}</span>
                  </div>
                  <div className="text-sm mb-2">
                    Attack: <span className="font-medium">{threat.type}</span>
                  </div>
                  <div className="space-y-1 text-xs">
                    <div className="p-2 bg-secondary/30 rounded">
                      <span className="text-cyan-400">⦿ Source</span>
                      <p className="font-mono text-red-400">{threat.sourceIp}</p>
                      <p className="text-muted-foreground">{threat.country}</p>
                    </div>
                    <div className="flex justify-center">
                      <ArrowRight className="h-4 w-4 text-muted-foreground" />
                    </div>
                    <div className="p-2 bg-secondary/30 rounded">
                      <span className="text-cyan-400">⦿ Target</span>
                      <p className="font-mono text-cyan-400">{threat.targetIp}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
