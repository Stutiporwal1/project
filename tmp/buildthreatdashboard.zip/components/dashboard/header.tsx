"use client"

import { Bell, BellOff, Shield, Database, Download, MessageSquare, History } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useState } from "react"

export function DashboardHeader() {
  const [alertsOn, setAlertsOn] = useState(false)

  return (
    <header className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-border/50">
      <div className="flex items-center gap-3">
        <div className="p-2 bg-cyan-500/20 rounded-lg">
          <Shield className="h-8 w-8 text-cyan-400" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-foreground">CyberShield SOC</h1>
          <p className="text-sm text-muted-foreground">Real-time Threat Intelligence Platform</p>
        </div>
      </div>

      <div className="flex flex-wrap items-center gap-2">
        <Button
          variant="outline"
          size="sm"
          className={`${alertsOn ? "bg-cyan-500/20 border-cyan-500/50" : "bg-secondary/50"}`}
          onClick={() => setAlertsOn(!alertsOn)}
        >
          {alertsOn ? <Bell className="h-4 w-4 mr-2" /> : <BellOff className="h-4 w-4 mr-2" />}
          {alertsOn ? "Alerts On" : "Alerts Off"}
        </Button>

        <Button variant="outline" size="sm" className="bg-green-500/20 border-green-500/50 text-green-400">
          <Shield className="h-4 w-4 mr-2" />
          100%+ Secured
        </Button>

        <Button variant="outline" size="sm" className="bg-secondary/50">
          <Database className="h-4 w-4 mr-2" />
          Connect DB
        </Button>

        <Button variant="outline" size="sm" className="bg-secondary/50">
          <Download className="h-4 w-4 mr-2" />
          Export
        </Button>

        <Button variant="outline" size="sm" className="bg-secondary/50">
          <MessageSquare className="h-4 w-4 mr-2" />
          Chat
        </Button>

        <Button variant="outline" size="sm" className="bg-secondary/50">
          <History className="h-4 w-4 mr-2" />
          History
        </Button>
      </div>
    </header>
  )
}
