"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Globe, MapPin, Wifi, Clock, ExternalLink } from "lucide-react"
import { generateAttackOrigins, type AttackOrigin, type SeverityLevel } from "@/lib/threat-data"
import { cn } from "@/lib/utils"

const severityBadgeColors: Record<SeverityLevel, string> = {
  Critical: "bg-red-500 text-white",
  High: "bg-pink-500 text-white",
  Medium: "bg-orange-500 text-black",
  Low: "bg-green-500 text-black",
}

const severityTextColors: Record<SeverityLevel, string> = {
  Critical: "text-red-500",
  High: "text-pink-500",
  Medium: "text-orange-500",
  Low: "text-green-500",
}

export function AttackOriginsGrid() {
  const [origins, setOrigins] = useState<AttackOrigin[]>([])
  const [mapProvider, setMapProvider] = useState<"google" | "osm">("google")

  useEffect(() => {
    setOrigins(generateAttackOrigins())

    // Refresh origins periodically
    const interval = setInterval(() => {
      setOrigins(generateAttackOrigins())
    }, 30000)

    return () => clearInterval(interval)
  }, [])

  return (
    <div className="space-y-4">
      {/* Geolocation Map Header */}
      <Card className="bg-card/50 border-border/50">
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <CardTitle className="text-cyan-400 flex items-center gap-2">
              <Globe className="h-5 w-5" />
              Threat Geolocation with Attack Paths
            </CardTitle>
            <div className="flex gap-2">
              <Button
                variant={mapProvider === "google" ? "default" : "outline"}
                size="sm"
                onClick={() => setMapProvider("google")}
                className={mapProvider === "google" ? "bg-cyan-500 hover:bg-cyan-600" : ""}
              >
                Google
              </Button>
              <Button
                variant={mapProvider === "osm" ? "default" : "outline"}
                size="sm"
                onClick={() => setMapProvider("osm")}
                className={mapProvider === "osm" ? "bg-cyan-500 hover:bg-cyan-600" : ""}
              >
                OSM
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {/* Simplified map visualization */}
          <div className="relative h-64 bg-gradient-to-b from-cyan-900/20 to-teal-900/20 rounded-lg overflow-hidden border border-border/30">
            <div className="absolute inset-0 opacity-30">
              <svg viewBox="0 0 800 400" className="w-full h-full">
                {/* World map simplified outline */}
                <path
                  d="M100,180 Q150,150 200,160 T300,150 T400,140 T500,150 T600,160 T700,180"
                  fill="none"
                  stroke="rgba(6, 182, 212, 0.3)"
                  strokeWidth="1"
                />
                <path
                  d="M120,200 Q200,180 280,190 T400,200 T520,190 T640,200 T720,220"
                  fill="none"
                  stroke="rgba(6, 182, 212, 0.3)"
                  strokeWidth="1"
                />
              </svg>
            </div>

            {/* Threat markers */}
            {origins.map((origin, index) => {
              const x = ((origin.coordinates.lng + 180) / 360) * 100
              const y = ((90 - origin.coordinates.lat) / 180) * 100
              return (
                <div
                  key={index}
                  className="absolute w-3 h-3 rounded-full animate-blink"
                  style={{
                    left: `${Math.max(5, Math.min(95, x))}%`,
                    top: `${Math.max(10, Math.min(90, y))}%`,
                    backgroundColor:
                      origin.severity === "Critical"
                        ? "#ef4444"
                        : origin.severity === "High"
                          ? "#ec4899"
                          : origin.severity === "Medium"
                            ? "#f97316"
                            : "#22c55e",
                    boxShadow: `0 0 10px ${
                      origin.severity === "Critical"
                        ? "#ef4444"
                        : origin.severity === "High"
                          ? "#ec4899"
                          : origin.severity === "Medium"
                            ? "#f97316"
                            : "#22c55e"
                    }`,
                  }}
                />
              )
            })}

            <p className="absolute bottom-2 left-2 text-xs text-muted-foreground">
              Blinking markers indicate active threat locations (color-coded by severity)
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Attack Origins Cards */}
      <Card className="bg-card/50 border-border/50">
        <CardHeader className="pb-4">
          <CardTitle className="text-cyan-400 flex items-center gap-2">
            <Globe className="h-5 w-5" />
            <MapPin className="h-4 w-4 text-pink-500" />
            Live Attack Origins - Click to View
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {origins.map((origin, index) => (
              <div
                key={index}
                className="p-4 rounded-lg border border-border/50 bg-secondary/20 hover:bg-secondary/40 transition-colors cursor-pointer"
              >
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-semibold text-foreground">{origin.country}</h3>
                  <Badge className={severityBadgeColors[origin.severity]}>{origin.severity}</Badge>
                </div>

                <p className={cn("text-sm font-medium mb-3", severityTextColors[origin.severity])}>
                  {origin.attackType}
                </p>

                <div className="space-y-2 text-xs text-muted-foreground">
                  <div className="flex items-center gap-2">
                    <MapPin className="h-3 w-3" />
                    <span>
                      {origin.coordinates.lat.toFixed(4)}°, {origin.coordinates.lng.toFixed(4)}°
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Wifi className="h-3 w-3" />
                    <span className="font-mono">{origin.sourceIp}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="h-3 w-3" />
                    <span>{origin.timestamp.toLocaleTimeString()}</span>
                  </div>
                </div>

                <Button variant="link" size="sm" className="mt-3 p-0 h-auto text-cyan-400">
                  <ExternalLink className="h-3 w-3 mr-1" />
                  View on Google Maps
                </Button>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
