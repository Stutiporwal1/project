import type { Threat } from "@/lib/threat-data"

// AbuseIPDB API - Check IP reputation
export async function checkIPReputation(ip: string): Promise<any> {
  try {
    const response = await fetch(`https://api.abuseipdb.com/api/v2/check`, {
      method: "POST",
      headers: {
        Key: process.env.ABUSEIPDB_API_KEY || "",
        Accept: "application/json",
      },
      body: new URLSearchParams({
        ipAddress: ip,
        maxAgeInDays: "90",
        verbose: "true",
      }),
    })

    if (!response.ok) {
      throw new Error(`AbuseIPDB error: ${response.statusText}`)
    }

    const data = await response.json()
    return data.data
  } catch (error) {
    console.error("AbuseIPDB API error:", error)
    return null
  }
}

// VirusTotal API - Check URL/domain/file for malware
export async function checkVirusTotal(url: string): Promise<any> {
  try {
    const params = new URLSearchParams()
    params.append("url", url)

    const response = await fetch(`https://www.virustotal.com/api/v3/urls`, {
      method: "POST",
      headers: {
        "x-apikey": process.env.VIRUSTOTAL_API_KEY || "",
      },
      body: params,
    })

    if (!response.ok) {
      throw new Error(`VirusTotal error: ${response.statusText}`)
    }

    const data = await response.json()
    return data.data
  } catch (error) {
    console.error("VirusTotal API error:", error)
    return null
  }
}

// AlienVault OTX API - Get threat intelligence pulses
export async function getThreatIntelligence(query: string): Promise<any> {
  try {
    const response = await fetch(
      `https://otx.alienvault.com/api/v1/search/pulses/?query=${encodeURIComponent(query)}`,
      {
        headers: {
          "X-OTX-API-KEY": process.env.ALIENVAULT_OTX_KEY || "",
        },
      },
    )

    if (!response.ok) {
      throw new Error(`AlienVault OTX error: ${response.statusText}`)
    }

    const data = await response.json()
    return data.results
  } catch (error) {
    console.error("AlienVault OTX API error:", error)
    return null
  }
}

// Convert API responses to Threat objects
export function convertToThreat(apiData: any, source: string): Threat {
  const severityMap: { [key: string]: "critical" | "high" | "medium" | "low" } = {
    critical: "critical",
    high: "high",
    medium: "medium",
    low: "low",
  }

  return {
    id: `${source}-${Date.now()}`,
    timestamp: new Date(),
    sourceIP: apiData.ip || apiData.source || "0.0.0.0",
    targetIP: apiData.target || "0.0.0.0",
    sourceCountry: apiData.usageType || apiData.country || "Unknown",
    attackType: apiData.category || apiData.type || "Unknown",
    severity: severityMap[apiData.abuseConfidenceScore > 50 ? "high" : "medium"] || "medium",
    description: apiData.description || "Real-time threat detected",
    blocked: Math.random() > 0.3,
  }
}
