// AEGIS - Minimal threat data types and generators

export type Severity = "critical" | "high" | "medium" | "low"

export type ThreatType =
  | "ransomware"
  | "ddos"
  | "phishing"
  | "malware"
  | "intrusion"
  | "exfiltration"
  | "cryptominer"
  | "botnet"

export interface Threat {
  id: string
  timestamp: Date
  type: ThreatType
  severity: Severity
  source: string
  target: string
  location: string
  status: "blocked" | "investigating" | "mitigated"
  confidence: number
}

export interface PulseData {
  timestamp: Date
  value: number
  anomaly: boolean
}

export interface RiskCell {
  category: string
  asset: string
  score: number
  trend: "up" | "down" | "stable"
}

export interface AttackStage {
  id: string
  name: string
  status: "complete" | "active" | "pending"
  threats: number
}

export interface NetworkNode {
  id: string
  type: "source" | "target" | "relay"
  label: string
  severity?: Severity
}

export interface NetworkEdge {
  from: string
  to: string
  active: boolean
}

export interface AIModel {
  id: string
  name: string
  accuracy: number
  status: "active" | "training" | "inactive"
}

export interface AttackOrigin {
  country: string
  code: string
  attacks: number
  severity: Severity
  trend: "up" | "down" | "stable"
}

export interface HistoricalData {
  date: string
  threats: number
  blocked: number
  critical: number
}

export interface Insight {
  id: string
  title: string
  description: string
  severity: Severity
  timestamp: Date
}

const threatTypes: ThreatType[] = [
  "ransomware",
  "ddos",
  "phishing",
  "malware",
  "intrusion",
  "exfiltration",
  "cryptominer",
  "botnet",
]

const severities: Severity[] = ["critical", "high", "medium", "low"]

const locations = ["US-East", "US-West", "EU-West", "EU-North", "APAC", "LATAM", "MEA", "Russia", "China", "India"]

const generateIp = () => `${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.*.***`

export function generateThreat(): Threat {
  return {
    id: Math.random().toString(36).slice(2, 8),
    timestamp: new Date(),
    type: threatTypes[Math.floor(Math.random() * threatTypes.length)],
    severity: severities[Math.floor(Math.random() * severities.length)],
    source: generateIp(),
    target: generateIp(),
    location: locations[Math.floor(Math.random() * locations.length)],
    status: "blocked",
    confidence: Math.floor(Math.random() * 20) + 80,
  }
}

export function generateThreats(count: number): Threat[] {
  return Array.from({ length: count }, (_, i) => {
    const threat = generateThreat()
    threat.timestamp = new Date(Date.now() - i * 3000)
    return threat
  })
}

export function generatePulseData(points: number): PulseData[] {
  const data: PulseData[] = []
  const now = Date.now()
  for (let i = points; i >= 0; i--) {
    const baseValue = 50 + Math.sin(i * 0.3) * 20
    const noise = (Math.random() - 0.5) * 15
    const value = Math.max(0, Math.min(100, baseValue + noise))
    const anomaly = Math.random() > 0.92
    data.push({
      timestamp: new Date(now - i * 2000),
      value: anomaly ? value + 30 : value,
      anomaly,
    })
  }
  return data
}

export function generateRiskMatrix(): RiskCell[] {
  const categories = ["Network", "Endpoint", "Cloud", "Identity", "Data"]
  const assets = ["Primary", "Secondary", "Backup"]
  const cells: RiskCell[] = []

  categories.forEach((category) => {
    assets.forEach((asset) => {
      cells.push({
        category,
        asset,
        score: Math.floor(Math.random() * 100),
        trend: ["up", "down", "stable"][Math.floor(Math.random() * 3)] as "up" | "down" | "stable",
      })
    })
  })
  return cells
}

export function generateNetworkData(): { nodes: NetworkNode[]; edges: NetworkEdge[] } {
  const nodes: NetworkNode[] = [
    { id: "attacker1", type: "source", label: "Attacker A", severity: "critical" },
    { id: "attacker2", type: "source", label: "Attacker B", severity: "high" },
    { id: "relay1", type: "relay", label: "Proxy 1" },
    { id: "relay2", type: "relay", label: "Proxy 2" },
    { id: "relay3", type: "relay", label: "C2 Server" },
    { id: "target1", type: "target", label: "DB Server", severity: "critical" },
    { id: "target2", type: "target", label: "Web Server", severity: "medium" },
    { id: "target3", type: "target", label: "Auth Service", severity: "high" },
  ]

  const edges: NetworkEdge[] = [
    { from: "attacker1", to: "relay1", active: true },
    { from: "attacker1", to: "relay2", active: false },
    { from: "attacker2", to: "relay2", active: true },
    { from: "relay1", to: "relay3", active: true },
    { from: "relay2", to: "relay3", active: true },
    { from: "relay3", to: "target1", active: true },
    { from: "relay3", to: "target2", active: false },
    { from: "relay3", to: "target3", active: true },
  ]

  return { nodes, edges }
}

export function generateAttackOrigins(): AttackOrigin[] {
  return [
    { country: "Russia", code: "RU", attacks: 2847, severity: "critical", trend: "up" },
    { country: "China", code: "CN", attacks: 2134, severity: "critical", trend: "up" },
    { country: "North Korea", code: "KP", attacks: 1256, severity: "high", trend: "stable" },
    { country: "Iran", code: "IR", attacks: 987, severity: "high", trend: "up" },
    { country: "United States", code: "US", attacks: 756, severity: "medium", trend: "down" },
    { country: "Brazil", code: "BR", attacks: 543, severity: "medium", trend: "stable" },
    { country: "India", code: "IN", attacks: 432, severity: "low", trend: "up" },
    { country: "Germany", code: "DE", attacks: 321, severity: "low", trend: "down" },
  ]
}

export function generateHistoricalData(days = 30): HistoricalData[] {
  const data: HistoricalData[] = []
  const now = new Date()

  for (let i = days; i >= 0; i--) {
    const date = new Date(now)
    date.setDate(date.getDate() - i)
    const baseThreats = 150 + Math.sin(i * 0.5) * 50
    const threats = Math.floor(baseThreats + (Math.random() - 0.5) * 40)
    const blocked = Math.floor(threats * (0.85 + Math.random() * 0.1))
    const critical = Math.floor(threats * (0.1 + Math.random() * 0.05))

    data.push({
      date: date.toISOString().split("T")[0],
      threats,
      blocked,
      critical,
    })
  }
  return data
}

export const aiModels: AIModel[] = [
  { id: "lstm-threat", name: "LSTM Threat Predictor", accuracy: 94.2, status: "active" },
  { id: "rf-classifier", name: "Random Forest Classifier", accuracy: 91.8, status: "active" },
  { id: "transformer", name: "Transformer Anomaly Detector", accuracy: 96.1, status: "training" },
  { id: "gnn-network", name: "GNN Network Analyzer", accuracy: 89.5, status: "inactive" },
]

export const attackTypeDistribution = [
  { name: "DDoS", value: 28, color: "#ef4444" },
  { name: "Malware", value: 22, color: "#f59e0b" },
  { name: "Phishing", value: 18, color: "#eab308" },
  { name: "Ransomware", value: 15, color: "#22c55e" },
  { name: "Intrusion", value: 10, color: "#06b6d4" },
  { name: "Other", value: 7, color: "#8b5cf6" },
]

export const severityDistribution = [
  { name: "Critical", value: 12, color: "#ef4444" },
  { name: "High", value: 28, color: "#f59e0b" },
  { name: "Medium", value: 35, color: "#eab308" },
  { name: "Low", value: 25, color: "#22c55e" },
]

export const insights: Insight[] = [
  {
    id: "1",
    title: "DDoS Attack Surge",
    description: "45% increase in DDoS attacks from Eastern Europe in the last 24 hours.",
    severity: "critical" as Severity,
    timestamp: new Date(),
  },
  {
    id: "2",
    title: "New Ransomware Variant",
    description: "AEGIS AI detected a new ransomware strain targeting financial institutions.",
    severity: "high" as Severity,
    timestamp: new Date(Date.now() - 3600000),
  },
  {
    id: "3",
    title: "Botnet Activity Detected",
    description: "Unusual traffic patterns suggest botnet reconnaissance on port 443.",
    severity: "medium" as Severity,
    timestamp: new Date(Date.now() - 7200000),
  },
  {
    id: "4",
    title: "Phishing Campaign Blocked",
    description: "Automated systems blocked 127 phishing emails targeting employees.",
    severity: "low" as Severity,
    timestamp: new Date(Date.now() - 10800000),
  },
]

export const severityColors: Record<Severity, string> = {
  critical: "#ef4444",
  high: "#f59e0b",
  medium: "#eab308",
  low: "#22c55e",
}

export const threatTypeLabels: Record<ThreatType, string> = {
  ransomware: "Ransomware",
  ddos: "DDoS",
  phishing: "Phishing",
  malware: "Malware",
  intrusion: "Intrusion",
  exfiltration: "Data Exfil",
  cryptominer: "Cryptominer",
  botnet: "Botnet",
}

export const killChainStages: AttackStage[] = [
  { id: "recon", name: "Reconnaissance", status: "complete", threats: 12 },
  { id: "weapon", name: "Weaponization", status: "complete", threats: 8 },
  { id: "delivery", name: "Delivery", status: "active", threats: 5 },
  { id: "exploit", name: "Exploitation", status: "pending", threats: 0 },
  { id: "install", name: "Installation", status: "pending", threats: 0 },
  { id: "command", name: "Command & Control", status: "pending", threats: 0 },
  { id: "action", name: "Actions", status: "pending", threats: 0 },
]
